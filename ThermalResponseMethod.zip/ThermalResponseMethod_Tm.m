clear; clc;

%% ======= Inputs =======
xlsx_file  = 'temp_data2.xlsx';   % Excel file (col1 = Time [s], col2 = Tm [-])
sheet_name = 1;                  % sheet index or name

TH = 80;                         % Hot Temperature setpoint [°C]
TL = 30;                         % Cold Temperature setpoint [°C]

UA = 18.69 * 0.4343;               % Overall conductance (U * A) [W/°C] (set [] if unknown)
t_cycle = 300;                   % Cycle duration [s] for NTU (set [] to skip)

% Fitting/plot options
use_weights = false;             % emphasize early-time samples
show_residuals = true;           % plot residuals
save_plots = false;              % save PNGs to disk

%% ======= LOAD DATA =======
data = readmatrix(xlsx_file, 'Sheet', sheet_name);
assert(size(data,2) >= 2, 'Excel must have at least two numeric columns: [Time, Tm].');

t  = data(:,1);          % Time [s]
TM = data(:,2);          % Measured Tm (normalized, dimensionless)
t  = t(:);  TM = TM(:);

% Clean and sort data
ok = isfinite(t) & isfinite(TM);
t = t(ok); TM = TM(ok);
[t, idx] = sort(t);
TM = TM(idx);
[t, ia] = unique(t, 'stable');   % ensuring unique timestamps
TM = TM(ia);
assert(numel(t) >= 8, 'Not enough samples after cleaning.');

%% ======= NONLINEAR FIT: TM = B + A * exp(-k*(t - t0)) =======
% Initial guesses
A0  = max(TM) - min(TM);
B0  = max(min(TM(end), 1), 0);   % keep within [0,1] for normalized data
span = t(end) - t(1);
k0  = 1 / max(5, 0.3*span);      % crude
t00 = t(1);                      % small time shift around first sample
p0  = [A0, B0, k0, t00];         % [A, B, k, t0]

% Bounds
lb = [-2,  0,    0,   t(1)-5];
ub = [ 2,  1,  Inf,   t(1)+5];

% Weights (optional: emphasize early time)
if use_weights
    t0w = 0.5*span;
    w = 1 ./ (1 + ((t - t(1))/t0w).^2);
else
    w = ones(size(t));
end

modfun = @(p, tq) p(2) + p(1).*exp(-p(3).*(tq - p(4)));   % B + A e^[-k(t-t0)]
obj    = @(p) sqrt(w).*(modfun(p,t) - TM);

opts = optimoptions('lsqnonlin','Display','iter','MaxFunctionEvaluations',3e4,...
                    'FunctionTolerance',1e-12,'StepTolerance',1e-12);
p = lsqnonlin(obj, p0, lb, ub, opts);
A = p(1); B = p(2); k = p(3); t0 = p(4);

TM_fit = modfun(p, t);

%% ======= DIAGNOSTICS & METRICS =======
res  = TM_fit - TM;
RMSE = sqrt(mean(res.^2));
SS_res = sum(res.^2);
SS_tot = sum((TM - mean(TM)).^2);
R2 = 1 - SS_res/SS_tot;

tau = 1/k;                     % time constant [s]
t_half = log(2)/k;             % half-time [s]
T_infty = TH - B*(TH - TL);    % asymptotic temperature [°C]

% Lumped parameters
mcp_eff = [];
if ~isempty(UA)
    mcp_eff = UA / k;          % [J/°C]
end

NTU = [];
if ~isempty(t_cycle)
    NTU = k * t_cycle;         % dimensionless
end

%% ======= REPORT =======
fprintf('\n=== Heating fit using provided Tm: TM = B + A * exp(-k*(t - t0)) ===\n');
fprintf('A        = %.6g\n', A);
fprintf('B        = %.6g\n', B);
fprintf('k        = %.6g 1/s\n', k);
fprintf('t0       = %.6g s\n', t0);
fprintf('tau      = %.6g s (1/k)\n', tau);
fprintf('t_half   = %.6g s (ln2/k)\n', t_half);
fprintf('T_infty  = %.6g (same units as TH/TL)\n', T_infty);
fprintf('RMSE     = %.3g\n', RMSE);
fprintf('R^2      = %.6f\n', R2);
if ~isempty(mcp_eff), fprintf('(m c_p)_eff = %.6g J/K\n', mcp_eff); end
if ~isempty(NTU),      fprintf('NTU (t_cycle=%.3g s) = %.6g\n', t_cycle, NTU); end

%% ======= PLOTS =======
figure('Name','Heating fit (Tm)'); hold on; grid on;
plot(t, TM, 'o', 'DisplayName','Measured Tm');
plot(t, TM_fit, '--', 'LineWidth',1.8, 'DisplayName','Fit: B + A e^{-k(t-t0)}');
xlabel('Time [s]'); ylabel('T_m [-]'); title('Heating: T_m(t) from Excel');
legend('Location','best');

if show_residuals
    figure('Name','Residuals'); hold on; grid on;
    plot(t, res, '.-');
    xlabel('Time [s]'); ylabel('Fit residual (T_{m,fit} - T_m)');
    title('Residuals');
end

if save_plots
    exportgraphics(gcf, 'TM_fit.png', 'Resolution', 200);
    if show_residuals
        figs = findobj('Type','Figure');
        if numel(figs) >= 2
            exportgraphics(figs(1), 'TM_fit.png', 'Resolution', 200);
            exportgraphics(figs(2), 'residuals.png', 'Resolution', 200);
        end
    end
end

%% ======= Temperature overlay (reconstructed from Tm) =======
T_meas = TH - TM*(TH - TL);          % reconstructed measured T from provided Tm
T_fit  = TH - TM_fit*(TH - TL);      % fitted T from fitted Tm

figure('Name','Temperature overlay'); hold on; grid on;
plot(t, T_meas, 'o', 'DisplayName','Reconstructed T from T_m');
plot(t, T_fit,  '--', 'LineWidth',1.8, 'DisplayName','Fitted T from T_{m,fit}');
xlabel('Time [s]'); ylabel('Temperature [°C]');
title('Temperature overlay (from T_m)'); legend('Location','best');
