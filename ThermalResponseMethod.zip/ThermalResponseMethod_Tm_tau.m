clear; clc;

%% ======= Inputs =======
xlsx_file  = 'temp_data2.xlsx';   % Excel file (col1 = Time [s], col2 = Tm [-])
sheet_name = 1;                   % sheet index or name

TH = 80;                          % Hot Temperature setpoint [°C]
TL = 30;                          % Cold Temperature setpoint [°C]

UA = 21.36 * 0.38;                % Overall conductance (U * A) [W/°C] (set [] if unknown)
t_cycle = 284;                    % Cycle duration [s] for NTU (set [] to skip)

% Fitting/plot options
use_weights   = false;            % emphasize early-time samples
show_residuals = true;            % plot residuals
save_plots    = false;            % save PNGs to disk
do_t0_scan    = true;             % coarse scan over t0 to get a robust initial guess

%% ======= LOAD DATA =======
data = readmatrix(xlsx_file, 'Sheet', sheet_name);
assert(size(data,2) >= 2, 'Excel must have at least two numeric columns: [Time, Tm].');

t  = data(:,1);          % Time [s]
TM = data(:,2);          % Measured Tm (normalized, dimensionless)
t  = t(:);  TM = TM(:);

% Clean and sort data
ok = isfinite(t) & isfinite(TM);
t  = t(ok); TM = TM(ok);
[t, idx] = sort(t);
TM = TM(idx);
[t, ia] = unique(t, 'stable');   % unique timestamps
TM = TM(ia);
assert(numel(t) >= 8, 'Not enough samples after cleaning.');

span = t(end) - t(1);

%% ======= Model (true dead time) =======
% TM(t) = B + A * exp(-k * max(0, t - t0))
% -> For t < t0, TM = B + A (constant). For t >= t0, exponential relax.
modfun = @(p, tq) p(2) + p(1).*exp(-p(3).*max(0, tq - p(4)));  % p=[A,B,k,t0]

%% ======= Initial guesses & bounds =======
% A ~ initial jump above B; B ~ asymptotic normalized TM
A0  = max(TM) - min(TM);                  % crude amplitude guess
B0  = max(min(TM(end), 1), 0);            % keep B in [0,1] for normalized data
k0  = 1 / max(5, 0.3*span);               % crude rate guess
t00 = t(1);                               % start scanning around first sample

% Bounds (allow wider room for t0 than before to capture real delay)
lb = [-2,  0,    0,   t(1)-0.5*span];
ub = [ 2,  1,  Inf,   t(end)];            % t0 cannot exceed last timestamp

% Weights (optional: emphasize early time)
if use_weights
    t0w = 0.5*span;
    w = 1 ./ (1 + ((t - t(1))/t0w).^2);
else
    w = ones(size(t));
end

% Objective with weights
obj_all = @(p) sqrt(w).*(modfun(p,t) - TM);

%% ======= Optional coarse scan over t0 (decoupled prefit) =======
% For each candidate t0, fit (A,B,k) only; choose t0 with min RMSE
if do_t0_scan
    % Build a candidate grid over t0 focusing on early times + a tail
    t0_grid = linspace(t(1), min(t(1)+0.5*span, t(end)), 21);
    best = struct('rmse', inf, 'p', []);
    opts_scan = optimoptions('lsqnonlin','Display','off',...
        'MaxFunctionEvaluations',1e4,'FunctionTolerance',1e-10,'StepTolerance',1e-10);

    for t0cand = t0_grid
        % With t0 fixed, fit A,B,k via lsqnonlin on reduced parameter vector q=[A,B,k]
        modfun_fix = @(q, tq) q(2) + q(1).*exp(-q(3).*max(0, tq - t0cand));
        obj_fix = @(q) sqrt(w).*(modfun_fix(q,t) - TM);

        % Initial guesses for q
        q0  = [A0, B0, max(k0, 1e-6)];
        qlb = [lb(1), lb(2), max(lb(3), 1e-8)];
        qub = [ub(1), ub(2), ub(3)];

        try
            q = lsqnonlin(obj_fix, q0, qlb, qub, opts_scan);
            TM_try = modfun_fix(q,t);
            res = TM_try - TM;
            rmse_try = sqrt(mean(res.^2));
            if rmse_try < best.rmse
                best.rmse = rmse_try;
                best.p = [q(:).', t0cand];  % [A,B,k,t0]
            end
        catch
            % skip failures
        end
    end

    if ~isempty(best.p)
        p0 = best.p;       % robust seed for joint fit
    else
        p0 = [A0, B0, k0, t00];
    end
else
    p0 = [A0, B0, k0, t00];
end

%% ======= Final joint nonlinear fit (A,B,k,t0) with true dead time =======
opts = optimoptions('lsqnonlin','Display','iter','MaxFunctionEvaluations',3e4,...
                    'FunctionTolerance',1e-12,'StepTolerance',1e-12);
p = lsqnonlin(obj_all, p0, lb, ub, opts);
A = p(1); B = p(2); k = p(3); t0 = p(4);

TM_fit = modfun(p, t);

%% ======= Diagnostics & metrics =======
res  = TM_fit - TM;
RMSE = sqrt(mean(res.^2));
SS_res = sum(res.^2);
SS_tot = sum((TM - mean(TM)).^2);
R2 = 1 - SS_res/SS_tot;

tau    = 1/k;                  % time constant [s]
t_half = log(2)/k;             % half-time [s]
T_infty = TH - B*(TH - TL);    % asymptotic temperature [°C]

% Lumped parameters
mcp_eff = [];
if ~isempty(UA)
    mcp_eff = UA / k;          % [J/°C]
end

NTU = [];
if ~isempty(t_cycle)
    NTU = k * t_cycle;         % dimensionless
end

%% ======= Report =======
fprintf('\n=== Heating fit with true dead time: TM = B + A * exp(-k*max(0, t - t0)) ===\n');
fprintf('A        = %.6g\n', A);
fprintf('B        = %.6g\n', B);
fprintf('k        = %.6g 1/s\n', k);
fprintf('t0       = %.6g s\n', t0);
fprintf('tau      = %.6g s (1/k)\n', tau);
fprintf('t_half   = %.6g s (ln2/k)\n', t_half);
fprintf('T_infty  = %.6g (same units as TH/TL)\n', T_infty);
fprintf('RMSE     = %.3g\n', RMSE);
fprintf('R^2      = %.6f\n', R2);
if ~isempty(mcp_eff), fprintf('(m c_p)_eff = %.6g J/K\n', mcp_eff); end
if ~isempty(NTU),      fprintf('NTU (t_cycle=%.3g s) = %.6g\n', t_cycle, NTU); end

%% ======= Plots (Tm) =======
figure('Name','Heating fit (Tm)'); hold on; grid on;
plot(t, TM, 'o', 'DisplayName','Measured T_m');
plot(t, TM_fit, '--', 'LineWidth',1.8, 'DisplayName','Fit: B + A e^{-k max(0,t-t0)}');
xline(t0, ':', 't_0', 'LabelVerticalAlignment','bottom', 'DisplayName','t_0');
xlabel('Time [s]'); ylabel('T_m [-]'); title('Heating: T_m(t) with true dead time');
legend('Location','best');

if show_residuals
    figure('Name','Residuals'); hold on; grid on;
    plot(t, res, '.-');
    xline(t0, ':', 't_0', 'LabelVerticalAlignment','bottom');
    xlabel('Time [s]'); ylabel('Fit residual (T_{m,fit} - T_m)');
    title('Residuals');
end

%% ======= Temperature overlay (reconstructed from Tm) =======
T_meas = TH - TM*(TH - TL);          % reconstructed measured T from provided Tm
T_fit  = TH - TM_fit*(TH - TL);      % fitted T from fitted Tm

figure('Name','Temperature overlay'); hold on; grid on;
plot(t, T_meas, 'o', 'DisplayName','Reconstructed T from T_m');
plot(t, T_fit,  '--', 'LineWidth',1.8, 'DisplayName','Fitted T from T_{m,fit}');
xline(t0, ':', 't_0', 'LabelVerticalAlignment','bottom');
xlabel('Time [s]'); ylabel('Temperature [°C]');
title('Temperature overlay (from T_m)'); legend('Location','best');

%% ======= Optional: save plots =======
if save_plots
    figs = findobj('Type','Figure');
    for i = 1:numel(figs)
        fname = sprintf('fig_%02d.png', i);
        exportgraphics(figs(i), fname, 'Resolution', 200);
    end
end
