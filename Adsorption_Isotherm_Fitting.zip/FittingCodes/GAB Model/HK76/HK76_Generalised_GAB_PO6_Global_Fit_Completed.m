% ============================================================
% Global generalised-GAB (PO6) regression for HK76
%
% Fits water adsorption isotherms simultaneously at 30, 45 and 60 °C.
%
% C(aw,T) = C0(T) /
%           (1 + B1*aw + B2*aw^2 + B3*aw^3 + B4*aw^4)
%
% C0(T) = Cref*exp[(DeltaH1-DeltaHm)/R*(1/T-1/Tref)]
%
% The regression proceeds sequentially:
% PO2 -> PO3 -> PO4 -> PO5 -> PO6
%
% Input file: Fitting2.xlsx
% Columns: P30, q30, P45, q45, P60, q60
% Units: P [Pa], q [mol kg^-1]
%
% Requires MATLAB Optimization Toolbox.
% ============================================================

clc; clear; close all;


%% Input
filename  = 'Fitting2.xlsx';
sheetName = 1;

Temps_C = [30,45,60];
T_ref   = 318.15;                  % K (45 °C)

aw_max_keep = 0.999;
aw_fit_max  = 0.99;

exclude_first_n_points = [1,1,1];

R = 8.314462618;                   % J mol^-1 K^-1

% Water saturation-pressure correlation
A_sat = 16.3872;
B_sat = 3885.7;
C_sat = 230.16;


%% Initial estimates
% Starting values from the converged HK76 PO2 fit
qm_0   = 6.71725537;               % mol kg^-1
K_0    = 0.262825157;
Cref_0 = 92.63027031;
dHC_0  = 13806.01789;              % J mol^-1

B_0 = zeros(1,4);

% Minimum permitted PO6 correction denominator
minimum_correction_denominator = 0.005;


%% Parameter bounds
qm_lower   = 1e-8;
qm_upper   = 100;

K_lower    = 1e-6;
K_upper    = 0.999999;

Cref_lower = 1e-8;
Cref_upper = 1e6;

dHC_lower  = -2e5;
dHC_upper  =  2e5;

B_lower = -20;
B_upper =  20;


%% Load data
raw = readmatrix(filename,'Sheet',sheetName);

Pcols = [1,3,5];
qcols = [2,4,6];

nT = numel(Temps_C);
TK_all = Temps_C(:)+273.15;

P_all        = cell(nT,1);
q_all        = cell(nT,1);
aw_all       = cell(nT,1);
fit_mask_all = cell(nT,1);

for i = 1:nT

    P = raw(:,Pcols(i));
    q = raw(:,qcols(i));

    valid = isfinite(P) & isfinite(q) & P > 0 & q > 0;

    P = P(valid);
    q = q(valid);

    [P,idx] = sort(P);
    q = q(idx);

    P0 = P0_water_Pa( ...
        TK_all(i),A_sat,B_sat,C_sat);

    aw = P./P0;

    keep = ...
        isfinite(aw) & ...
        aw >= 0 & ...
        aw < aw_max_keep & ...
        q > 0;

    P  = P(keep);
    q  = q(keep);
    aw = aw(keep);

    fitMask = aw <= aw_fit_max;

    nExclude = exclude_first_n_points(i);

    if nExclude > 0
        fitMask(1:min(nExclude,numel(fitMask))) = false;
    end

    if nnz(fitMask) < 7
        error('Insufficient fitting data at %.0f °C.',Temps_C(i));
    end

    P_all{i}        = P;
    q_all{i}        = q;
    aw_all{i}       = aw;
    fit_mask_all{i} = fitMask;

    fprintf('%.0f °C: %d points used in fit\n', ...
        Temps_C(i),nnz(fitMask));
end

constraint_aw_grid = ...
    linspace(0,min(aw_fit_max,0.999999),250).';


%% Stage 0: PO2 baseline
x0_PO2 = [qm_0; K_0; Cref_0; dHC_0];

lb_PO2 = [ ...
    qm_lower
    K_lower
    Cref_lower
    dHC_lower];

ub_PO2 = [ ...
    qm_upper
    K_upper
    Cref_upper
    dHC_upper];

opts_lsq = optimoptions('lsqnonlin', ...
    'Display','final', ...
    'FunctionTolerance',1e-12, ...
    'StepTolerance',1e-12, ...
    'OptimalityTolerance',1e-10, ...
    'MaxIterations',5000, ...
    'MaxFunctionEvaluations',100000);

resfun_PO2 = @(x) residuals_global_PO_order( ...
    x,0,aw_all,q_all,fit_mask_all,TK_all,T_ref,R);

[x_stage,resnorm_PO2,~,exitflag_PO2] = ...
    lsqnonlin( ...
        resfun_PO2,x0_PO2,lb_PO2,ub_PO2,opts_lsq);

if exitflag_PO2 <= 0
    error('The PO2 baseline regression did not converge.');
end


%% Sequential PO3-PO6 regression
opts_fmincon = optimoptions('fmincon', ...
    'Algorithm','sqp', ...
    'Display','final', ...
    'ScaleProblem',true, ...
    'FiniteDifferenceType','central', ...
    'ConstraintTolerance',1e-10, ...
    'OptimalityTolerance',1e-9, ...
    'StepTolerance',1e-12, ...
    'MaxIterations',5000, ...
    'MaxFunctionEvaluations',200000);

stage_resnorm = nan(5,1);
stage_resnorm(1) = resnorm_PO2;

for polynomial_order = 1:4

    x0_stage = [x_stage; B_0(polynomial_order)];

    lb_stage = [ ...
        qm_lower
        K_lower
        Cref_lower
        dHC_lower
        repmat(B_lower,polynomial_order,1)];

    ub_stage = [ ...
        qm_upper
        K_upper
        Cref_upper
        dHC_upper
        repmat(B_upper,polynomial_order,1)];

    objective = @(x) objective_SSE_global_PO_order( ...
        x,polynomial_order,aw_all,q_all, ...
        fit_mask_all,TK_all,T_ref,R);

    constraint = @(x) denominator_constraint_global_PO_order( ...
        x,polynomial_order,constraint_aw_grid, ...
        minimum_correction_denominator);

    [x_candidate,fval,exitflag] = fmincon( ...
        objective,x0_stage,[],[],[],[], ...
        lb_stage,ub_stage,constraint,opts_fmincon);

    if exitflag <= 0
        error('PO%d regression did not converge.', ...
            polynomial_order+2);
    end

    % Independent correction-denominator check
    aw_check = linspace( ...
        0,min(aw_fit_max,0.999999),5000).';

    D_check = correction_denominator_polynomial( ...
        aw_check,x_candidate(5:end));

    if any(~isfinite(D_check)) || ...
            min(D_check) < minimum_correction_denominator-1e-8

        error('PO%d failed the correction-denominator check.', ...
            polynomial_order+2);
    end

    x_stage = x_candidate;
    stage_resnorm(polynomial_order+1) = fval;

    fprintf('PO%d converged: residual norm = %.8g\n', ...
        polynomial_order+2,fval);
end


%% Final PO6 parameters
x_fit = x_stage;

qm_fit   = x_fit(1);
K_fit    = x_fit(2);
Cref_fit = x_fit(3);
dHC_fit  = x_fit(4);
B_fit    = reshape(x_fit(5:8),1,4);

C0_T = Cref_fit.*exp( ...
    (dHC_fit./R).*((1./TK_all)-(1./T_ref)));


%% PO6 polynomial coefficients
% aw/q = A0 + A1*aw + ... + A6*aw^6

A = nan(nT,7);

for i = 1:nT

    A(i,:) = PO6_coefficients_from_parameters( ...
        qm_fit,K_fit,C0_T(i),B_fit);

end


%% Predictions and fit statistics
q_model_all = cell(nT,1);

Nfit = nan(nT,1);
RMSE = nan(nT,1);
R2   = nan(nT,1);
MAE  = nan(nT,1);
AARD = nan(nT,1);

q_exp_pool   = [];
q_model_pool = [];

for i = 1:nT

    q_model = generalized_GAB_PO6_q( ...
        aw_all{i},qm_fit,K_fit,C0_T(i),B_fit);

    q_model_all{i} = q_model;

    valid = ...
        fit_mask_all{i} & ...
        isfinite(q_model) & ...
        isfinite(q_all{i}) & ...
        q_all{i} > 0;

    q_exp   = q_all{i}(valid);
    q_model = q_model(valid);

    residual = q_model-q_exp;

    Nfit(i) = numel(q_exp);
    RMSE(i) = sqrt(mean(residual.^2));
    MAE(i)  = mean(abs(residual));
    AARD(i) = 100*mean(abs(residual./q_exp));

    SS_res = sum(residual.^2);
    SS_tot = sum((q_exp-mean(q_exp)).^2);

    R2(i) = 1-SS_res/SS_tot;

    q_exp_pool   = [q_exp_pool; q_exp]; %#ok<AGROW>
    q_model_pool = [q_model_pool; q_model]; %#ok<AGROW>

end


%% Pooled statistics
residual_pool = q_model_pool-q_exp_pool;

RMSE_pool = sqrt(mean(residual_pool.^2));
MAE_pool  = mean(abs(residual_pool));
AARD_pool = 100*mean(abs(residual_pool./q_exp_pool));

SS_res = sum(residual_pool.^2);
SS_tot = sum((q_exp_pool-mean(q_exp_pool)).^2);

R2_pool = 1-SS_res/SS_tot;


%% Results
fprintf('\n=== HK76 generalised-GAB PO6 fit ===\n');
fprintf('Fitting range: aw <= %.3f\n\n',aw_fit_max);

fprintf('qm                  = %.8g mol kg^-1\n',qm_fit);
fprintf('K                   = %.8g\n',K_fit);
fprintf('Cref (%.2f K)       = %.8g\n',T_ref,Cref_fit);
fprintf('DeltaH1 - DeltaHm   = %.8g kJ mol^-1\n',dHC_fit/1000);

fprintf('B1                  = %.8g\n',B_fit(1));
fprintf('B2                  = %.8g\n',B_fit(2));
fprintf('B3                  = %.8g\n',B_fit(3));
fprintf('B4                  = %.8g\n',B_fit(4));

fprintf('Residual norm       = %.8g\n',stage_resnorm(5));


%% C0(T) and polynomial coefficients
fprintf('\n=== C0(T) and PO6 coefficients ===\n');

for i = 1:nT

    fprintf('\nT = %.0f °C   C0 = %.8g\n', ...
        Temps_C(i),C0_T(i));

    fprintf(['A0 = %.8g   A1 = %.8g   A2 = %.8g   ' ...
             'A3 = %.8g\n'], ...
        A(i,1),A(i,2),A(i,3),A(i,4));

    fprintf('A4 = %.8g   A5 = %.8g   A6 = %.8g\n', ...
        A(i,5),A(i,6),A(i,7));

end


%% Fit statistics
fprintf('\n=== Fit statistics ===\n');
fprintf('T (°C)     N       R^2       RMSE       MAE       AARD (%%)\n');

for i = 1:nT

    fprintf('%5.0f    %3d    %8.5f   %9.5g  %9.5g   %9.4f\n', ...
        Temps_C(i),Nfit(i),R2(i),RMSE(i),MAE(i),AARD(i));

end

fprintf('\n=== Pooled statistics ===\n');
fprintf('R^2   = %.6f\n',R2_pool);
fprintf('RMSE  = %.6g mol kg^-1\n',RMSE_pool);
fprintf('MAE   = %.6g mol kg^-1\n',MAE_pool);
fprintf('AARD  = %.4f %%\n',AARD_pool);


%% Fitted isotherms
figure('Color','w');
hold on;

for i = 1:nT

    scatter(aw_all{i},q_all{i},45,'filled', ...
        'DisplayName',sprintf('%.0f °C experimental',Temps_C(i)));

    aw_plot = linspace(0,aw_fit_max,500).';

    q_plot = generalized_GAB_PO6_q( ...
        aw_plot,qm_fit,K_fit,C0_T(i),B_fit);

    plot(aw_plot,q_plot,'LineWidth',2, ...
        'DisplayName',sprintf('%.0f °C PO6 fit',Temps_C(i)));

end

xlabel('Water activity, a_w');
ylabel('Water uptake, q (mol kg^{-1})');

xlim([0,aw_max_keep]);

legend('Location','best');

grid on;
box on;


%% Residuals
figure('Color','w');
hold on;

for i = 1:nT

    fitMask = fit_mask_all{i};

    residual = ...
        q_model_all{i}(fitMask)-q_all{i}(fitMask);

    scatter(aw_all{i}(fitMask),residual,45,'filled', ...
        'DisplayName',sprintf('%.0f °C',Temps_C(i)));

end

yline(0,'--');

xlabel('Water activity, a_w');
ylabel('Residual, q_{model}-q_{exp} (mol kg^{-1})');

legend('Location','best');

grid on;
box on;


%% Physical-domain check
aw_check = linspace( ...
    0,min(aw_fit_max,0.999999),5000).';

D_check = correction_denominator_polynomial( ...
    aw_check,B_fit);

fprintf('\n=== Physical-domain check ===\n');
fprintf('Minimum correction denominator = %.8g\n',min(D_check));

for i = 1:nT

    q_check = generalized_GAB_PO6_q( ...
        aw_check,qm_fit,K_fit,C0_T(i),B_fit);

    dq_daw = diff(q_check)./diff(aw_check);

    valid_domain = ...
        all(isfinite(q_check)) && ...
        all(q_check >= 0) && ...
        all(D_check >= minimum_correction_denominator-1e-8) && ...
        all(dq_daw >= -1e-8);

    fprintf('%.0f °C: valid and monotonic = %d\n', ...
        Temps_C(i),valid_domain);

end


%% Local functions
function P0 = P0_water_Pa(T_K,A_sat,B_sat,C_sat)

    T_C = T_K-273.15;

    P0 = 1e3.*exp( ...
        A_sat-B_sat./(T_C+C_sat));

end


function r = residuals_global_PO_order( ...
    x,polynomial_order,aw_all,q_all,fit_mask_all,TK_all,T_ref,R)

    qm   = x(1);
    K    = x(2);
    Cref = x(3);
    dHC  = x(4);

    B = x(5:end);

    if numel(B) ~= polynomial_order
        r = 1e6;
        return;
    end

    C0_T = Cref.*exp( ...
        (dHC./R).*((1./TK_all)-(1./T_ref)));

    r = [];

    for i = 1:numel(TK_all)

        fitMask = fit_mask_all{i};

        aw = aw_all{i}(fitMask);
        q_exp = q_all{i}(fitMask);

        q_model = generalized_GAB_PO_order_q( ...
            aw,qm,K,C0_T(i),B);

        if any(~isfinite(q_model))

            r_i = 1e6.*ones(size(q_exp));

        else

            r_i = q_model-q_exp;

        end

        r = [r; r_i]; %#ok<AGROW>

    end

    r(~isfinite(r)) = 1e6;

end


function SSE = objective_SSE_global_PO_order( ...
    x,polynomial_order,aw_all,q_all,fit_mask_all,TK_all,T_ref,R)

    r = residuals_global_PO_order( ...
        x,polynomial_order,aw_all,q_all, ...
        fit_mask_all,TK_all,T_ref,R);

    SSE = sum(r.^2);

    if ~isfinite(SSE)
        SSE = realmax('double')/100;
    end

end


function [c,ceq] = denominator_constraint_global_PO_order( ...
    x,polynomial_order,aw_grid,minimum_denominator)

    B = x(5:end);

    if numel(B) ~= polynomial_order

        c = 1e6.*ones(size(aw_grid));
        ceq = [];
        return;

    end

    D = correction_denominator_polynomial(aw_grid,B);

    c = minimum_denominator-D;
    ceq = [];

end


function D = correction_denominator_polynomial(aw,B)

    D = ones(size(aw));

    for j = 1:numel(B)
        D = D+B(j).*aw.^j;
    end

end


function q = generalized_GAB_PO_order_q(aw,qm,K,C0,B)

    D = correction_denominator_polynomial(aw,B);

    Cgen = C0./D;

    denominator = ...
        (1-K.*aw).* ...
        (1-K.*aw+Cgen.*K.*aw);

    q = qm.*Cgen.*K.*aw./denominator;

    invalid = ...
        D <= 0 | ...
        denominator <= 0 | ...
        ~isfinite(q) | ...
        q < 0 | ...
        aw < 0 | ...
        aw >= 1;

    q(invalid) = NaN;

end


function q = generalized_GAB_PO6_q(aw,qm,K,C0,B)

    q = generalized_GAB_PO_order_q( ...
        aw,qm,K,C0,B);

end


function A = PO6_coefficients_from_parameters(qm,K,C0,B)

    % aw/q = A0 + A1*aw + ... + A6*aw^6

    D = [1,B(:).'];

    one_minus_Kaw_squared = [1,-2*K,K^2];

    numerator = conv( ...
        D,one_minus_Kaw_squared);

    numerator(2) = numerator(2)+C0*K;
    numerator(3) = numerator(3)-C0*K^2;

    A = numerator./(qm*C0*K);

end