% ============================================================
% Global generalised-GAB (PO3) regression for HK76
%
% Fits water adsorption isotherms simultaneously at 30, 45 and 60 °C.
%
% C(aw,T) = C0(T)/(1 + B1*aw)
%
% C0(T) = Cref*exp[(DeltaH1-DeltaHm)/R*(1/T-1/Tref)]
%
% Five global parameters are fitted:
% qm, K, Cref, DeltaH1-DeltaHm and B1
%
% Input file: Fitting2.xlsx
% Columns: P30, q30, P45, q45, P60, q60
% Units: P [Pa], q [mol kg^-1]
%
% Requires MATLAB Optimization Toolbox.
% ============================================================

clc; clear; close all;


%% Input
filename  = 'Fitting2.xlsx';
sheetName = 1;

Temps_C = [30,45,60];
T_ref   = 318.15;                  % K (45 °C)

aw_max_keep = 0.999;
aw_fit_max  = 0.999;

exclude_first_n_points = [0,0,0];

R = 8.314462618;                   % J mol^-1 K^-1

% Water saturation-pressure correlation
A_sat = 16.3872;
B_sat = 3885.7;
C_sat = 230.16;


%% Multistart initial values
qm_start_values   = [4.5,6.71725537,8.0];
K_start_values    = [0.10,0.262825157,0.50];
Cref_start_values = [50,92.63027031,200];
dHC_start_values  = [5500,13806.01789,20000];
B1_start_values   = [-0.90,-0.50,0,0.50,1.00];

minimum_correction_denominator = 0.005;


%% Parameter bounds
qm_lower   = 1e-8;
qm_upper   = 100;

K_lower    = 1e-6;
K_upper    = 0.999999;

Cref_lower = 1e-8;
Cref_upper = 1e6;

dHC_lower  = -2e5;
dHC_upper  =  2e5;

B1_upper = 1e4;


%% Load data
raw = readmatrix(filename,'Sheet',sheetName);

Pcols = [1,3,5];
qcols = [2,4,6];

nT = numel(Temps_C);
TK_all = Temps_C(:)+273.15;

P_all        = cell(nT,1);
q_all        = cell(nT,1);
aw_all       = cell(nT,1);
fit_mask_all = cell(nT,1);

for i = 1:nT

    P = raw(:,Pcols(i));
    q = raw(:,qcols(i));

    valid = ...
        isfinite(P) & ...
        isfinite(q) & ...
        P > 0 & ...
        q > 0;

    P = P(valid);
    q = q(valid);

    [P,idx] = sort(P);
    q = q(idx);

    P0 = P0_water_Pa( ...
        TK_all(i),A_sat,B_sat,C_sat);

    aw = P./P0;

    keep = ...
        isfinite(aw) & ...
        aw >= 0 & ...
        aw < aw_max_keep & ...
        q > 0;

    P  = P(keep);
    q  = q(keep);
    aw = aw(keep);

    fitMask = aw <= aw_fit_max;

    nExclude = exclude_first_n_points(i);

    if nExclude > 0
        fitMask(1:min(nExclude,numel(fitMask))) = false;
    end

    if nnz(fitMask) < 4
        error('Insufficient fitting data at %.0f °C.',Temps_C(i));
    end

    P_all{i}        = P;
    q_all{i}        = q;
    aw_all{i}       = aw;
    fit_mask_all{i} = fitMask;

    fprintf('%.0f °C: %d points used in fit\n', ...
        Temps_C(i),nnz(fitMask));
end


%% B1 lower bound
% Ensures:
% 1 + B1*aw >= minimum_correction_denominator

aw_bound = min(aw_fit_max,0.999999);

B1_lower = ...
    (minimum_correction_denominator-1)./aw_bound;

lb = [ ...
    qm_lower
    K_lower
    Cref_lower
    dHC_lower
    B1_lower];

ub = [ ...
    qm_upper
    K_upper
    Cref_upper
    dHC_upper
    B1_upper];


%% Multistart global PO3 regression
opts = optimoptions('lsqnonlin', ...
    'Display','off', ...
    'FunctionTolerance',1e-12, ...
    'StepTolerance',1e-12, ...
    'OptimalityTolerance',1e-10, ...
    'MaxIterations',10000, ...
    'MaxFunctionEvaluations',200000);

resfun = @(x) residuals_globalB1_PO3( ...
    x,aw_all,q_all,fit_mask_all,TK_all,T_ref,R, ...
    minimum_correction_denominator,aw_fit_max);

nStarts = ...
    numel(qm_start_values)* ...
    numel(K_start_values)* ...
    numel(Cref_start_values)* ...
    numel(dHC_start_values)* ...
    numel(B1_start_values);

fprintf('\n=== HK76 PO3 multistart regression ===\n');
fprintf('Number of starts = %d\n',nStarts);

best_resnorm = Inf;
x_fit = [];
best_start = [];
best_start_number = NaN;

startCounter = 0;

for iqm = 1:numel(qm_start_values)
for iK = 1:numel(K_start_values)
for iC = 1:numel(Cref_start_values)
for iH = 1:numel(dHC_start_values)
for iB = 1:numel(B1_start_values)

    startCounter = startCounter+1;

    x0 = [ ...
        qm_start_values(iqm)
        K_start_values(iK)
        Cref_start_values(iC)
        dHC_start_values(iH)
        B1_start_values(iB)];

    if any(x0 < lb) || any(x0 > ub)
        continue;
    end

    try

        [x_candidate,resnorm_candidate,~,exitflag_candidate] = ...
            lsqnonlin(resfun,x0,lb,ub,opts);

    catch
        continue;
    end

    [domain_valid,monotonic] = ...
        validate_globalB1_PO3_candidate( ...
            x_candidate,TK_all,T_ref,R,aw_fit_max, ...
            minimum_correction_denominator,5000);

    accepted = ...
        exitflag_candidate > 0 && ...
        isfinite(resnorm_candidate) && ...
        domain_valid && ...
        monotonic;

    if accepted && resnorm_candidate < best_resnorm

        best_resnorm = resnorm_candidate;
        x_fit = x_candidate;
        best_start = x0;
        best_start_number = startCounter;

        fprintf( ...
            'New best: start %d/%d, residual norm = %.10g\n', ...
            startCounter,nStarts,best_resnorm);
    end

end
end
end
end
end

if isempty(x_fit)
    error('No physically valid PO3 solution was found.');
end


%% Final PO3 parameters
qm_fit   = x_fit(1);
K_fit    = x_fit(2);
Cref_fit = x_fit(3);
dHC_fit  = x_fit(4);
B1_fit   = x_fit(5);

C0_T = Cref_fit.*exp( ...
    (dHC_fit./R).*((1./TK_all)-(1./T_ref)));


%% PO3 polynomial coefficients
% aw/q = A0 + A1*aw + A2*aw^2 + A3*aw^3

A0 = nan(nT,1);
A1 = nan(nT,1);
A2 = nan(nT,1);
A3 = nan(nT,1);

for i = 1:nT

    [A0(i),A1(i),A2(i),A3(i)] = ...
        PO3_coefficients_from_parameters( ...
            qm_fit,K_fit,C0_T(i),B1_fit);

end


%% Predictions and fit statistics
q_model_all = cell(nT,1);

Nfit = nan(nT,1);
RMSE = nan(nT,1);
R2   = nan(nT,1);
MAE  = nan(nT,1);
AARD = nan(nT,1);

q_exp_pool   = [];
q_model_pool = [];

for i = 1:nT

    q_model = generalized_GAB_PO3_q( ...
        aw_all{i},qm_fit,K_fit,C0_T(i),B1_fit);

    q_model_all{i} = q_model;

    valid = ...
        fit_mask_all{i} & ...
        isfinite(q_model) & ...
        isfinite(q_all{i}) & ...
        q_all{i} > 0;

    q_exp   = q_all{i}(valid);
    q_model = q_model(valid);

    residual = q_model-q_exp;

    Nfit(i) = numel(q_exp);
    RMSE(i) = sqrt(mean(residual.^2));
    MAE(i)  = mean(abs(residual));
    AARD(i) = 100*mean(abs(residual./q_exp));

    SS_res = sum(residual.^2);
    SS_tot = sum((q_exp-mean(q_exp)).^2);

    if SS_tot > 0
        R2(i) = 1-SS_res/SS_tot;
    end

    q_exp_pool   = [q_exp_pool; q_exp]; %#ok<AGROW>
    q_model_pool = [q_model_pool; q_model]; %#ok<AGROW>

end


%% Pooled statistics
residual_pool = q_model_pool-q_exp_pool;

RMSE_pool = sqrt(mean(residual_pool.^2));
MAE_pool  = mean(abs(residual_pool));
AARD_pool = 100*mean(abs(residual_pool./q_exp_pool));

SS_res = sum(residual_pool.^2);
SS_tot = sum((q_exp_pool-mean(q_exp_pool)).^2);

R2_pool = 1-SS_res/SS_tot;


%% Results
fprintf('\n=== HK76 generalised-GAB PO3 fit ===\n');
fprintf('Fitting range: aw <= %.3f\n\n',aw_fit_max);

fprintf('qm                  = %.8g mol kg^-1\n',qm_fit);
fprintf('K                   = %.8g\n',K_fit);
fprintf('Cref (%.2f K)       = %.8g\n',T_ref,Cref_fit);
fprintf('DeltaH1 - DeltaHm   = %.8g kJ mol^-1\n',dHC_fit/1000);
fprintf('B1                  = %.8g\n',B1_fit);
fprintf('Residual norm       = %.8g\n',best_resnorm);

fprintf('\nBest multistart initial condition:\n');
fprintf('Start number         = %d\n',best_start_number);
fprintf('qm                   = %.8g\n',best_start(1));
fprintf('K                    = %.8g\n',best_start(2));
fprintf('Cref                 = %.8g\n',best_start(3));
fprintf('DeltaH               = %.8g kJ mol^-1\n',best_start(4)/1000);
fprintf('B1                   = %.8g\n',best_start(5));


%% C0(T) and polynomial coefficients
fprintf('\n=== C0(T) and PO3 coefficients ===\n');

for i = 1:nT

    fprintf('\nT = %.0f °C   C0 = %.8g\n', ...
        Temps_C(i),C0_T(i));

    fprintf( ...
        'A0 = %.8g   A1 = %.8g   A2 = %.8g   A3 = %.8g\n', ...
        A0(i),A1(i),A2(i),A3(i));

end


%% Fit statistics
fprintf('\n=== Fit statistics ===\n');
fprintf('T (°C)     N       R^2       RMSE       MAE       AARD (%%)\n');

for i = 1:nT

    fprintf('%5.0f    %3d    %8.5f   %9.5g  %9.5g   %9.4f\n', ...
        Temps_C(i),Nfit(i),R2(i),RMSE(i),MAE(i),AARD(i));

end

fprintf('\n=== Pooled statistics ===\n');
fprintf('R^2   = %.6f\n',R2_pool);
fprintf('RMSE  = %.6g mol kg^-1\n',RMSE_pool);
fprintf('MAE   = %.6g mol kg^-1\n',MAE_pool);
fprintf('AARD  = %.4f %%\n',AARD_pool);


%% Fitted isotherms
figure('Color','w');
hold on;

for i = 1:nT

    scatter(aw_all{i},q_all{i},45,'filled', ...
        'DisplayName',sprintf('%.0f °C experimental',Temps_C(i)));

    aw_plot = linspace(0,aw_fit_max,500).';

    q_plot = generalized_GAB_PO3_q( ...
        aw_plot,qm_fit,K_fit,C0_T(i),B1_fit);

    plot(aw_plot,q_plot,'LineWidth',2, ...
        'DisplayName',sprintf('%.0f °C PO3 fit',Temps_C(i)));

end

xlabel('Water activity, a_w');
ylabel('Water uptake, q (mol kg^{-1})');

xlim([0,aw_max_keep]);

legend('Location','best');
grid on;
box on;


%% Residuals
figure('Color','w');
hold on;

for i = 1:nT

    fitMask = fit_mask_all{i};

    residual = ...
        q_model_all{i}(fitMask)-q_all{i}(fitMask);

    scatter(aw_all{i}(fitMask),residual,45,'filled', ...
        'DisplayName',sprintf('%.0f °C',Temps_C(i)));

end

yline(0,'--');

xlabel('Water activity, a_w');
ylabel('Residual, q_{model}-q_{exp} (mol kg^{-1})');

legend('Location','best');
grid on;
box on;


%% Physical-domain check
aw_check = linspace( ...
    0,min(aw_fit_max,0.999999),5000).';

correction_denominator = 1+B1_fit.*aw_check;

fprintf('\n=== Physical-domain check ===\n');
fprintf('Minimum correction denominator = %.8g\n', ...
    min(correction_denominator));

for i = 1:nT

    Cgen_check = C0_T(i)./correction_denominator;

    model_denominator = ...
        (1-K_fit.*aw_check).* ...
        (1-K_fit.*aw_check + ...
         Cgen_check.*K_fit.*aw_check);

    q_check = generalized_GAB_PO3_q( ...
        aw_check,qm_fit,K_fit,C0_T(i),B1_fit);

    dq_daw = diff(q_check)./diff(aw_check);

    valid_domain = ...
        all(isfinite(q_check)) && ...
        all(q_check >= 0) && ...
        all(correction_denominator >= ...
            minimum_correction_denominator-1e-8) && ...
        all(model_denominator > 0) && ...
        all(dq_daw >= -1e-8);

    fprintf('%.0f °C: valid and monotonic = %d\n', ...
        Temps_C(i),valid_domain);

end


%% Local functions
function P0 = P0_water_Pa(T_K,A_sat,B_sat,C_sat)

    T_C = T_K-273.15;

    P0 = 1e3.*exp( ...
        A_sat-B_sat./(T_C+C_sat));

end


function r = residuals_globalB1_PO3( ...
    x,aw_all,q_all,fit_mask_all,TK_all,T_ref,R, ...
    minimum_correction_denominator,aw_fit_max)

    qm   = x(1);
    K    = x(2);
    Cref = x(3);
    dHC  = x(4);
    B1   = x(5);

    nResiduals = 0;

    for i = 1:numel(fit_mask_all)
        nResiduals = nResiduals+nnz(fit_mask_all{i});
    end

    if ...
            ~isfinite(qm) || qm <= 0 || ...
            ~isfinite(K) || K <= 0 || K >= 1 || ...
            ~isfinite(Cref) || Cref <= 0 || ...
            ~isfinite(dHC) || ...
            ~isfinite(B1)

        r = 1e6.*ones(max(nResiduals,1)+1,1);
        return;
    end

    C0_T = Cref.*exp( ...
        (dHC./R).*((1./TK_all)-(1./T_ref)));

    if any(~isfinite(C0_T)) || any(C0_T <= 0)
        r = 1e6.*ones(max(nResiduals,1)+1,1);
        return;
    end

    minimum_correction = min( ...
        1, ...
        1+B1.*min(aw_fit_max,0.999999));

    domain_violation = max( ...
        0, ...
        minimum_correction_denominator-minimum_correction);

    domain_penalty = 1e5.*domain_violation;

    r = [];

    for i = 1:numel(C0_T)

        aw = aw_all{i};
        q_exp = q_all{i};
        fitMask = fit_mask_all{i};

        correction_denominator = 1+B1.*aw;

        if any(correction_denominator(fitMask) < ...
                minimum_correction_denominator)

            r_i = 1e4.*ones(nnz(fitMask),1);

        else

            q_model = generalized_GAB_PO3_q( ...
                aw,qm,K,C0_T(i),B1);

            valid = ...
                fitMask & ...
                isfinite(q_exp) & ...
                isfinite(q_model) & ...
                q_exp > 0;

            if nnz(valid) ~= nnz(fitMask)

                r_i = 1e4.*ones(nnz(fitMask),1);

            else

                r_i = q_model(valid)-q_exp(valid);

            end
        end

        r = [r; r_i]; %#ok<AGROW>

    end

    r = [r; domain_penalty];

    r(~isfinite(r)) = 1e6;

end


function q = generalized_GAB_PO3_q(aw,qm,K,C0,B1)

    correction_denominator = 1+B1.*aw;

    Cgen = C0./correction_denominator;

    denominator = ...
        (1-K.*aw).* ...
        (1-K.*aw+Cgen.*K.*aw);

    q = qm.*Cgen.*K.*aw./denominator;

    invalid = ...
        correction_denominator <= 0 | ...
        denominator <= 0 | ...
        ~isfinite(q) | ...
        q < 0 | ...
        aw < 0 | ...
        aw >= 1;

    q(invalid) = NaN;

end


function [domainValid,monotonicIncreasing] = ...
    validate_globalB1_PO3_candidate( ...
        x,TK_all,T_ref,R,aw_fit_max, ...
        minimum_correction_denominator,nGrid)

    qm   = x(1);
    K    = x(2);
    Cref = x(3);
    dHC  = x(4);
    B1   = x(5);

    domainValid = false;
    monotonicIncreasing = false;

    if ...
            any(~isfinite(x)) || ...
            qm <= 0 || ...
            K <= 0 || K >= 1 || ...
            Cref <= 0 || ...
            nGrid < 2
        return;
    end

    C0_T = Cref.*exp( ...
        (dHC./R).*((1./TK_all)-(1./T_ref)));

    if any(~isfinite(C0_T)) || any(C0_T <= 0)
        return;
    end

    aw_check = linspace( ...
        0,min(aw_fit_max,0.999999),nGrid).';

    correction_denominator = 1+B1.*aw_check;

    if ...
            any(~isfinite(correction_denominator)) || ...
            any(correction_denominator < ...
                minimum_correction_denominator)
        return;
    end

    domainValid = true;
    monotonicIncreasing = true;

    for i = 1:numel(C0_T)

        q_check = generalized_GAB_PO3_q( ...
            aw_check,qm,K,C0_T(i),B1);

        Cgen_check = C0_T(i)./correction_denominator;

        model_denominator = ...
            (1-K.*aw_check).* ...
            (1-K.*aw_check + ...
             Cgen_check.*K.*aw_check);

        if ...
                any(~isfinite(q_check)) || ...
                any(q_check < 0) || ...
                any(~isfinite(model_denominator)) || ...
                any(model_denominator <= 0)

            domainValid = false;
            monotonicIncreasing = false;
            return;
        end

        dq_daw = diff(q_check)./diff(aw_check);

        if any(~isfinite(dq_daw)) || any(dq_daw < -1e-8)
            monotonicIncreasing = false;
            return;
        end

    end

end


function [A0,A1,A2,A3] = ...
    PO3_coefficients_from_parameters(qm,K,C0,B1)

    A0 = 1./(qm.*C0.*K);

    A1 = A0.*( ...
        B1+C0.*K-2.*K);

    A2 = A0.*K.*( ...
        -2.*B1-C0.*K+K);

    A3 = A0.*B1.*K.^2;

end