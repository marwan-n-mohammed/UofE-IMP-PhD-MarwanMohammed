% ============================================================
% CBV400 STANDARD GAB / PO2
% NUMERICAL ISOSTERIC HEAT CALCULATION
%
% hst = R*T^2*(d ln(P)/dT)_q
%
% The derivative is evaluated numerically at constant uptake
% using a central finite difference.
% ============================================================

clear; clc; close all;


%% Parameters

% Water saturation-pressure correlation
Asat = 16.3872;
Bsat = 3885.7;
Csat = 230.16;

R = 8.314462/1000;          % kJ mol^-1 K^-1

% CBV400 standard GAB / PO2 parameters
qm = 13.78;                 % mol kg^-1
K = 0.10;                   % dimensionless

Cref = 117.91;              % C0(Tref), dimensionless
Tref = 45 + 273.15;         % K

deltah = 8.32;              % DeltaH1 - DeltaHm, kJ mol^-1


%% Temperature dependence of C

% C(T) = Cref*exp[(deltah/R)*(1/T - 1/Tref)]
%
% Equivalent form:
%
% C(T) = c0*exp(deltah/(R*T))

c0 = Cref / exp(deltah/(R*Tref));


%% Temperatures

Tlist_C = [30 45 60];       % degC
Tlist = Tlist_C + 273.15;   % K


%% Uptake range

qgrid = linspace(0.09,20,300);   % mol kg^-1


%% Numerical differentiation settings

dT = 0.05;                  % K

% CBV400 PO2 regression was restricted to aw <= 0.75
aw_upper = 0.75;


%% Preallocate

nT = length(Tlist);
nq = length(qgrid);

Qst = nan(nq,nT);


%% Calculate isosteric heat

for i = 1:nT

    T = Tlist(i);

    for j = 1:nq

        qtarget = qgrid(j);


        % ----------------------------------------------------
        % Pressure at T + dT for the same uptake
        % ----------------------------------------------------

        Pplus = pressure_from_q_PO2( ...
            qtarget,T+dT, ...
            Asat,Bsat,Csat,R,qm,K,c0,deltah, ...
            aw_upper);


        % ----------------------------------------------------
        % Pressure at T - dT for the same uptake
        % ----------------------------------------------------

        Pminus = pressure_from_q_PO2( ...
            qtarget,T-dT, ...
            Asat,Bsat,Csat,R,qm,K,c0,deltah, ...
            aw_upper);


        % ----------------------------------------------------
        % Numerical Clausius-Clapeyron derivative
        %
        % (d ln P/dT)_q =
        %
        % [ln P(T+dT) - ln P(T-dT)]/(2*dT)
        %
        % hst = R*T^2*(d ln P/dT)_q
        % ----------------------------------------------------

        if isfinite(Pplus) && ...
           isfinite(Pminus) && ...
           Pplus > 0 && ...
           Pminus > 0

            dlnPdT = ...
                (log(Pplus)-log(Pminus))/(2*dT);

            Qst(j,i) = ...
                R*T^2*dlnPdT;

        end

    end

end


%% Plot

figure;
hold on;

for i = 1:nT

    plot( ...
        qgrid, ...
        Qst(:,i), ...
        'LineWidth',1.8, ...
        'DisplayName',sprintf( ...
        '%g ^oC',Tlist_C(i)));

end

xlabel('Water uptake, q (mol kg^{-1})');

ylabel('Isosteric heat, h_{st} (kJ mol^{-1})');

legend('Location','best');

grid on;
box on;

hold off;


%% Display valid uptake ranges

fprintf('\n');
fprintf('=============================================\n');
fprintf('CBV400 PO2 ISOSTERIC HEAT\n');
fprintf('=============================================\n');

fprintf('\nValidated activity range: aw <= %.2f\n',aw_upper);
fprintf('Numerical temperature step: %.3f K\n\n',dT);

for i = 1:nT

    valid = isfinite(Qst(:,i));

    if any(valid)

        qvalid = qgrid(valid);

        fprintf( ...
            'T = %.0f °C: q = %.4f to %.4f mol kg^-1\n', ...
            Tlist_C(i), ...
            min(qvalid), ...
            max(qvalid));

    else

        fprintf( ...
            'T = %.0f °C: no valid points\n', ...
            Tlist_C(i));

    end

end


%% ============================================================
% LOCAL FUNCTIONS
% ============================================================


function Psat = psat_water(T,Asat,Bsat,Csat)

    % Water saturation pressure
    %
    % ln(Psat) =
    % Asat - Bsat/(T + Csat - 273.15)

    Psat = exp( ...
        Asat ...
        - Bsat/(T + Csat - 273.15));

end


function C = C_temperature(T,R,c0,deltah)

    % Temperature-dependent standard-GAB parameter

    C = ...
        c0*exp(deltah/(R*T));

end


function q = uptake_PO2( ...
    aw,T,R,qm,K,c0,deltah)

    % --------------------------------------------------------
    % Temperature-dependent C
    % --------------------------------------------------------

    C = ...
        C_temperature( ...
            T,R,c0,deltah);


    % --------------------------------------------------------
    % Standard GAB / PO2 isotherm
    %
    % q =
    %
    % qm*C*K*aw
    % -------------------------------
    % (1-K*aw)*(1-K*aw+C*K*aw)
    % --------------------------------------------------------

    denominator = ...
        (1-K.*aw).* ...
        (1-K.*aw+C.*K.*aw);

    q = ...
        qm.*C.*K.*aw ./ denominator;


    % --------------------------------------------------------
    % Reject nonphysical values
    % --------------------------------------------------------

    invalid = ...
        ~isfinite(q) | ...
        denominator <= 0 | ...
        aw < 0 | ...
        aw >= 1;

    q(invalid) = NaN;

end


function P = pressure_from_q_PO2( ...
    qtarget,T, ...
    Asat,Bsat,Csat,R,qm,K,c0,deltah, ...
    aw_upper)

    % --------------------------------------------------------
    % Saturation pressure
    % --------------------------------------------------------

    Psat = ...
        psat_water( ...
            T,Asat,Bsat,Csat);


    % --------------------------------------------------------
    % Function to invert:
    %
    % q(aw,T) - qtarget = 0
    % --------------------------------------------------------

    f = @(aw) ...
        uptake_PO2( ...
            aw,T,R,qm,K,c0,deltah) ...
        - qtarget;


    % --------------------------------------------------------
    % Valid water-activity interval
    % --------------------------------------------------------

    aw_lower = 1e-12;

    aw_upper = ...
        min(aw_upper,0.999999);


    % --------------------------------------------------------
    % Determine accessible uptake range
    % --------------------------------------------------------

    q_lower = ...
        uptake_PO2( ...
            aw_lower,T,R,qm,K,c0,deltah);

    q_upper = ...
        uptake_PO2( ...
            aw_upper,T,R,qm,K,c0,deltah);


    % --------------------------------------------------------
    % Reject target uptake outside validated model range
    % --------------------------------------------------------

    if ...
        ~isfinite(q_lower) || ...
        ~isfinite(q_upper) || ...
        qtarget < q_lower || ...
        qtarget > q_upper

        P = NaN;
        return;

    end


    % --------------------------------------------------------
    % Solve q(aw,T) = qtarget
    % --------------------------------------------------------

    try

        aw = ...
            fzero( ...
                f, ...
                [aw_lower aw_upper]);

    catch

        P = NaN;
        return;

    end


    % --------------------------------------------------------
    % Final physical check
    % --------------------------------------------------------

    if ...
        ~isfinite(aw) || ...
        aw <= 0 || ...
        aw > aw_upper

        P = NaN;
        return;

    end


    % --------------------------------------------------------
    % Convert water activity to pressure
    %
    % aw = P/Psat
    % --------------------------------------------------------

    P = aw*Psat;

end