% ============================================================
% HK76 PO6 ISOSTERIC HEAT
% NUMERICAL FINITE DIFFERENCE vs ANALYTICAL EXPRESSION
% ============================================================

clear; clc; close all;


%% Parameters

% Water saturation-pressure correlation
Asat = 16.3872;
Bsat = 3885.7;
Csat = 230.16;

R = 8.314462/1000;          % kJ mol^-1 K^-1

% HK76 PO6 parameters
qm = 6.53;                  % mol kg^-1
K  = 0.33;

c0 = 0.337974;
deltah = 13.74;             % kJ mol^-1

B1 = -4.99;
B2 = 16.15;
B3 = -8.98;
B4 = -2.71;


%% Temperature and uptake range

% One temperature
Tlist_C = 30;

% For all three temperatures use:
% Tlist_C = [30 45 60];

Tlist = Tlist_C + 273.15;   % K

qgrid = linspace(0.09,9,250);   % mol kg^-1

% Numerical finite-difference step
dT = 0.05;                  % K

% Maximum water activity used for inversion
aw_upper = 0.99;


%% Preallocate

nT = length(Tlist);
nq = length(qgrid);

Qst_numerical  = nan(nq,nT);
Qst_analytical = nan(nq,nT);
aw_result      = nan(nq,nT);


%% Calculate isosteric heat

for i = 1:nT

    T = Tlist(i);

    for j = 1:nq

        qtarget = qgrid(j);


        % ====================================================
        % METHOD 1
        % NUMERICAL FINITE-DIFFERENCE METHOD
        %
        % hst = R*T^2*(d ln P/dT)_q
        %
        % d ln P/dT =
        % [ln P(T+dT) - ln P(T-dT)]/(2*dT)
        % ====================================================

        Pplus = pressure_from_q_PO6( ...
            qtarget,T+dT, ...
            Asat,Bsat,Csat,R,qm,K,c0,deltah, ...
            B1,B2,B3,B4,aw_upper);

        Pminus = pressure_from_q_PO6( ...
            qtarget,T-dT, ...
            Asat,Bsat,Csat,R,qm,K,c0,deltah, ...
            B1,B2,B3,B4,aw_upper);

        if isfinite(Pplus) && ...
           isfinite(Pminus) && ...
           Pplus > 0 && ...
           Pminus > 0

            dlnPdT = ...
                (log(Pplus)-log(Pminus))/(2*dT);

            Qst_numerical(j,i) = ...
                R*T^2*dlnPdT;

        end


        % ====================================================
        % METHOD 2
        % ANALYTICAL PO6 EXPRESSION
        % ====================================================

        aw = aw_from_q_PO6( ...
            qtarget,T,R,qm,K,c0,deltah, ...
            B1,B2,B3,B4,aw_upper);

        aw_result(j,i) = aw;

        if ~isfinite(aw) || aw <= 0 || aw >= 1
            continue
        end


        % ----------------------------------------------------
        % Temperature-dependent C0(T)
        %
        % C0(T) = c0*exp(deltah/(R*T))
        % ----------------------------------------------------

        C0T = ...
            c0*exp(deltah/(R*T));


        % ----------------------------------------------------
        % PO6 correction polynomial
        %
        % D(aw) =
        % 1 + B1*aw + B2*aw^2 + B3*aw^3 + B4*aw^4
        % ----------------------------------------------------

        D = ...
            1 ...
            + B1*aw ...
            + B2*aw^2 ...
            + B3*aw^3 ...
            + B4*aw^4;


        % ----------------------------------------------------
        % Derivative of correction polynomial
        %
        % D'(aw) =
        % B1 + 2*B2*aw + 3*B3*aw^2 + 4*B4*aw^3
        % ----------------------------------------------------

        Dprime = ...
            B1 ...
            + 2*B2*aw ...
            + 3*B3*aw^2 ...
            + 4*B4*aw^3;


        % ----------------------------------------------------
        % Generalised GAB C parameter
        %
        % C(aw,T) = C0(T)/D(aw)
        % ----------------------------------------------------

        C = C0T/D;


        % ----------------------------------------------------
        % GAB denominator terms
        % ----------------------------------------------------

        S = 1-K*aw;

        H = ...
            1-K*aw+C*K*aw;


        % ----------------------------------------------------
        % Phi = d(ln q)/daw
        %
        % Phi =
        %
        % -D'/D
        % + 1/aw
        % + K/(1-K*aw)
        % - K*(C - 1 - aw*C*D'/D)/H
        % ----------------------------------------------------

        Phi = ...
            -Dprime/D ...
            + 1/aw ...
            + K/S ...
            - K*( ...
                C ...
                - 1 ...
                - aw*C*Dprime/D ...
                )/H;


        % ----------------------------------------------------
        % Saturation-pressure contribution
        %
        % ln(Psat) =
        % Asat - Bsat/(T + Csat - 273.15)
        %
        % d ln(Psat)/dT =
        % Bsat/(T + Csat - 273.15)^2
        % ----------------------------------------------------

        dlnPsatdT = ...
            Bsat/(T + Csat - 273.15)^2;


        % ----------------------------------------------------
        % Analytical PO6 isosteric heat
        %
        % hst =
        %
        % (deltah/aw)*(S/H)*(1/Phi)
        %
        % + R*T^2*dln(Psat)/dT
        % ----------------------------------------------------

        Qst_analytical(j,i) = ...
            (deltah/aw) ...
            * (S/H) ...
            * (1/Phi) ...
            + R*T^2*dlnPsatdT;

    end

end


%% Figure 1
% Numerical vs analytical hst

figure;
hold on;

for i = 1:nT

    plot( ...
        qgrid, ...
        Qst_numerical(:,i), ...
        '-', ...
        'LineWidth',1.8, ...
        'DisplayName',sprintf( ...
        'Numerical, %g ^oC',Tlist_C(i)));

    plot( ...
        qgrid, ...
        Qst_analytical(:,i), ...
        '--', ...
        'LineWidth',1.8, ...
        'DisplayName',sprintf( ...
        'Analytical, %g ^oC',Tlist_C(i)));

end

xlabel('Water uptake, q (mol kg^{-1})');

ylabel('Isosteric heat, h_{st} (kJ mol^{-1})');

legend('Location','best');

grid on;
box on;

hold off;


%% Figure 2
% Difference between methods

figure;
hold on;

for i = 1:nT

    difference = ...
        Qst_analytical(:,i) ...
        - Qst_numerical(:,i);

    plot( ...
        qgrid, ...
        difference, ...
        'LineWidth',1.5, ...
        'DisplayName',sprintf( ...
        '%g ^oC',Tlist_C(i)));

end

yline(0,'--');

xlabel('Water uptake, q (mol kg^{-1})');

ylabel( ...
    'Analytical - Numerical (kJ mol^{-1})');

legend('Location','best');

grid on;
box on;

hold off;


%% Numerical comparison

fprintf('\n');
fprintf('=============================================\n');
fprintf('NUMERICAL vs ANALYTICAL hst COMPARISON\n');
fprintf('=============================================\n');

for i = 1:nT

    difference = ...
        Qst_analytical(:,i) ...
        - Qst_numerical(:,i);

    valid = isfinite(difference);

    fprintf('\nT = %.0f °C\n',Tlist_C(i));

    if any(valid)

        fprintf( ...
            'Maximum absolute difference = %.8g kJ mol^-1\n', ...
            max(abs(difference(valid))));

        fprintf( ...
            'Mean absolute difference    = %.8g kJ mol^-1\n', ...
            mean(abs(difference(valid))));

    else

        fprintf('No common valid points.\n');

    end

end


%% ============================================================
% LOCAL FUNCTIONS
% ============================================================


function Psat = psat_water(T,Asat,Bsat,Csat)

    Psat = exp( ...
        Asat ...
        - Bsat/(T + Csat - 273.15));

end


function q = uptake_PO6( ...
    aw,T,R,qm,K,c0,deltah,B1,B2,B3,B4)

    % Temperature-dependent C0
    C0T = ...
        c0*exp(deltah/(R*T));

    % PO6 correction polynomial
    D = ...
        1 ...
        + B1*aw ...
        + B2*aw.^2 ...
        + B3*aw.^3 ...
        + B4*aw.^4;

    % Generalised GAB parameter
    C = C0T./D;

    % Generalised GAB isotherm
    denominator = ...
        (1-K.*aw).* ...
        (1-K.*aw+C.*K.*aw);

    q = ...
        qm.*C.*K.*aw ./ denominator;

    % Reject nonphysical values
    invalid = ...
        ~isfinite(q) | ...
        D <= 0 | ...
        denominator <= 0 | ...
        aw < 0 | ...
        aw >= 1;

    q(invalid) = NaN;

end


function P = pressure_from_q_PO6( ...
    qtarget,T, ...
    Asat,Bsat,Csat,R,qm,K,c0,deltah, ...
    B1,B2,B3,B4,aw_upper)

    % Saturation pressure
    Psat = ...
        psat_water( ...
            T,Asat,Bsat,Csat);

    % Isotherm inversion function
    f = @(aw) ...
        uptake_PO6( ...
            aw,T,R,qm,K,c0,deltah, ...
            B1,B2,B3,B4) ...
        - qtarget;

    aw_lower = 1e-12;

    aw_upper = ...
        min(aw_upper,0.999999);


    % Check accessible uptake range
    q_lower = ...
        uptake_PO6( ...
            aw_lower,T,R,qm,K,c0,deltah, ...
            B1,B2,B3,B4);

    q_upper = ...
        uptake_PO6( ...
            aw_upper,T,R,qm,K,c0,deltah, ...
            B1,B2,B3,B4);

    if ...
        ~isfinite(q_lower) || ...
        ~isfinite(q_upper) || ...
        qtarget < q_lower || ...
        qtarget > q_upper

        P = NaN;
        return;

    end


    % Solve q(aw,T) = qtarget
    try

        aw = ...
            fzero( ...
                f, ...
                [aw_lower aw_upper]);

    catch

        P = NaN;
        return;

    end


    if ...
        ~isfinite(aw) || ...
        aw <= 0 || ...
        aw > aw_upper

        P = NaN;
        return;

    end

    % P = aw*Psat
    P = aw*Psat;

end


function aw = aw_from_q_PO6( ...
    qtarget,T,R,qm,K,c0,deltah, ...
    B1,B2,B3,B4,aw_upper)

    f = @(aw) ...
        uptake_PO6( ...
            aw,T,R,qm,K,c0,deltah, ...
            B1,B2,B3,B4) ...
        - qtarget;

    aw_lower = 1e-12;

    aw_upper = ...
        min(aw_upper,0.999999);


    % Check accessible uptake range
    q_lower = ...
        uptake_PO6( ...
            aw_lower,T,R,qm,K,c0,deltah, ...
            B1,B2,B3,B4);

    q_upper = ...
        uptake_PO6( ...
            aw_upper,T,R,qm,K,c0,deltah, ...
            B1,B2,B3,B4);

    if ...
        ~isfinite(q_lower) || ...
        ~isfinite(q_upper) || ...
        qtarget < q_lower || ...
        qtarget > q_upper

        aw = NaN;
        return;

    end


    % Solve q(aw,T) = qtarget
    try

        aw = ...
            fzero( ...
                f, ...
                [aw_lower aw_upper]);

    catch

        aw = NaN;
        return;

    end


    if ...
        ~isfinite(aw) || ...
        aw <= 0 || ...
        aw > aw_upper

        aw = NaN;

    end

end