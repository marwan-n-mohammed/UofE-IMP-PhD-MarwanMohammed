clc; clear; close all;

%% ================= USER SETTINGS =================
filename  = 'Fitting2.xlsx';   % single sheet, 6 columns: P30 q30 P45 q45 P60 q60
sheetName = 1;                 % 1 or 'Sheet1'

Temps_C = [30, 45, 60];        % fixed by your file format
aw_max_keep = 0.999;           % filter near aw->1 to avoid singularities

% Optional: weight each temperature equally (useful if one T has more points)
equalWeightPerTemp = true;

%% ================= CONSTANTS =================
R = 8.314462618;               % J/mol/K

% Your P0 correlation constants
A_sat = 16.3872;
B_sat = 3885.7;
C_sat = 230.16;

%% ================= LOAD DATA (ONE SHEET, 6 COLUMNS) =================
raw = readmatrix(filename, 'Sheet', sheetName);

Pcols = [1, 3, 5];
qcols = [2, 4, 6];

nT = numel(Temps_C);

P_all  = cell(nT,1);
q_all  = cell(nT,1);
TK_all = (Temps_C(:) + 273.15);
Npts   = zeros(nT,1);

for i = 1:nT
    P = raw(:, Pcols(i));
    q = raw(:, qcols(i));

    % Clean: remove NaN/Inf and non-physical
    mask = isfinite(P) & isfinite(q) & P > 0 & q >= 0;
    P = P(mask); q = q(mask);

    % Sort by pressure
    [P, idx] = sort(P);
    q = q(idx);

    % Compute P0(T) and aw, then optionally filter near aw -> 1
    P0 = P0_water_Pa(TK_all(i), A_sat, B_sat, C_sat);
    aw = P ./ P0;

    keep = (aw >= 0) & (aw < aw_max_keep);
    P = P(keep);
    q = q(keep);

    P_all{i} = P;
    q_all{i} = q;
    Npts(i)  = numel(P);
end

%% ================= GLOBAL MODEL (3 PARAMETERS) =================
qmax_all = max(cellfun(@(v) max(v), q_all));
qm0  = 0.6 * qmax_all;

dH1_0 =  8000;   % J/mol
dHm_0 = -2000;   % J/mol

x0 = [log(max(qm0, eps)), dH1_0, dHm_0];

lb = [-Inf, -Inf, -Inf];
ub = [ Inf,  Inf,  0   ];   % enforce dHm <= 0  => K(T) <= 1

%% ================= FIT (ALL TEMPS AT ONCE) =================
opts = optimoptions('lsqnonlin', ...
    'Display','iter', ...
    'FunctionTolerance',1e-12, ...
    'StepTolerance',1e-12, ...
    'OptimalityTolerance',1e-10, ...
    'MaxIterations',10000, ...
    'MaxFunctionEvaluations',20000);

resfun = @(x) globalResidualsWeighted(x, P_all, q_all, TK_all, Npts, equalWeightPerTemp, ...
                                      R, A_sat, B_sat, C_sat);

[x_fit, resnorm, residual, exitflag] = lsqnonlin(resfun, x0, lb, ub, opts);

qm_fit  = exp(x_fit(1));
dH1_fit = x_fit(2);   % J/mol = ΔH1 - ΔHL
dHm_fit = x_fit(3);   % J/mol = ΔHm - ΔHL

fprintf('\n=== GLOBAL 3-TEMPERATURE GAB FIT (single sheet, 6 columns) ===\n');
fprintf('q_m                         = %.6g mol/kg\n', qm_fit);
fprintf('dH1 = (ΔH1 - ΔHL)            = %.6g J/mol (%.4f kJ/mol)\n', dH1_fit, dH1_fit/1000);
fprintf('dHm = (ΔHm - ΔHL)            = %.6g J/mol (%.4f kJ/mol)\n', dHm_fit, dHm_fit/1000);
fprintf('Difference (ΔH1-ΔHm)         = %.6g J/mol (%.4f kJ/mol)\n', (dH1_fit - dHm_fit), (dH1_fit - dHm_fit)/1000);
fprintf('exitflag                     = %d\n', exitflag);

%% ================= TSA-READY SINGLE FUNCTION q(P,T) =================
qPT = @(P, T_K) GAB_qPT(P, T_K, qm_fit, dH1_fit, dHm_fit, R, A_sat, B_sat, C_sat);

%% ================= HEATS OF ADSORPTION (relative + absolute + differences) =================
C_i = exp(dH1_fit ./ (R .* TK_all));
K_i = exp(dHm_fit ./ (R .* TK_all));

dHL_i = waterLatentHeat_Jmol(TK_all);   % J/mol
dH1_abs_i = dH1_fit + dHL_i;            % J/mol
dHm_abs_i = dHm_fit + dHL_i;            % J/mol

dH_diff_rel = dH1_fit - dHm_fit;        % J/mol
dH_diff_abs_i = dH1_abs_i - dHm_abs_i;  % J/mol

fprintf('\n=== Derived quantities at each temperature (relative + absolute heats) ===\n');
fprintf('Reminder: dH1,dHm are relative to ΔHL. Absolute uses ΔHL(T) correlation.\n\n');

for i = 1:nT
    fprintf('T = %.0f°C:\n', Temps_C(i));
    fprintf('   C=%.6g, K=%.6g\n', C_i(i), K_i(i));
    fprintf('   ΔHL(T)           = %+8.3f kJ/mol   (|ΔHL|=%.3f)\n', dHL_i(i)/1000, abs(dHL_i(i))/1000);
    fprintf('   dH1=ΔH1-ΔHL       = %+8.3f kJ/mol\n', dH1_fit/1000);
    fprintf('   dHm=ΔHm-ΔHL       = %+8.3f kJ/mol\n', dHm_fit/1000);
    fprintf('   ΔH1(T)=dH1+ΔHL    = %+8.3f kJ/mol   (|ΔH1|=%.3f)\n', dH1_abs_i(i)/1000, abs(dH1_abs_i(i))/1000);
    fprintf('   ΔHm(T)=dHm+ΔHL    = %+8.3f kJ/mol   (|ΔHm|=%.3f)\n', dHm_abs_i(i)/1000, abs(dHm_abs_i(i))/1000);
    fprintf('   (ΔH1-ΔHm)         = %+8.3f kJ/mol   [check: %+8.3f]\n\n', ...
        dH_diff_rel/1000, dH_diff_abs_i(i)/1000);
end

%% ================= OPTIONAL PLOT: ABSOLUTE HEATS VS TEMPERATURE =================
figure;
plot(Temps_C, dH1_abs_i/1000, '-o', 'LineWidth', 2); hold on;
plot(Temps_C, dHm_abs_i/1000, '-s', 'LineWidth', 2);
plot(Temps_C, (dHL_i)/1000,   '-^', 'LineWidth', 2);
xlabel('Temperature (°C)');
ylabel('Heat (kJ/mol)');
title('Absolute Heats (signed): ΔH1(T), ΔHm(T) and ΔHL(T)');
legend('\DeltaH_1(T)', '\DeltaH_m(T)', '\DeltaH_L(T)', 'Location','best');
grid on;

figure;
plot(Temps_C, abs(dH1_abs_i)/1000, '-o', 'LineWidth', 2); hold on;
plot(Temps_C, abs(dHm_abs_i)/1000, '-s', 'LineWidth', 2);
xlabel('Temperature (°C)');
ylabel('|Heat| (kJ/mol)');
title('Absolute Heat Magnitudes: |\DeltaH_1(T)| and |\DeltaH_m(T)|');
legend('|\DeltaH_1(T)|', '|\DeltaH_m(T)|', 'Location','best');
grid on;

%% ================= VAN ’T HOFF PLOTS =================
invT = 1 ./ TK_all;

% Plot ln(C) vs 1/T
figure;
scatter(invT, log(C_i), 80, 'filled'); hold on;
pC = polyfit(invT, log(C_i), 1);
xline = linspace(min(invT)*0.999, max(invT)*1.001, 200);
plot(xline, polyval(pC, xline), 'LineWidth', 2);
xlabel('1/T (1/K)'); ylabel('ln(C)');
title('van ''t Hoff Plot: ln(C) vs 1/T');
grid on;

dH1_from_vH = pC(1) * R;
fprintf('\nvan ''t Hoff (ln C): slope = %.6g -> dH1=(ΔH1-ΔHL) = %.6g J/mol (%.4f kJ/mol)\n', ...
    pC(1), dH1_from_vH, dH1_from_vH/1000);

% Plot ln(K) vs 1/T
figure;
scatter(invT, log(K_i), 80, 'filled'); hold on;
pK = polyfit(invT, log(K_i), 1);
plot(xline, polyval(pK, xline), 'LineWidth', 2);
xlabel('1/T (1/K)'); ylabel('ln(K)');
title('van ''t Hoff Plot: ln(K) vs 1/T');
grid on;

dHm_from_vH = pK(1) * R;
fprintf('van ''t Hoff (ln K): slope = %.6g -> dHm=(ΔHm-ΔHL) = %.6g J/mol (%.4f kJ/mol)\n', ...
    pK(1), dHm_from_vH, dHm_from_vH/1000);

fprintf('Check: (dH1-dHm) from fit = %.4f kJ/mol\n', (dH1_fit - dHm_fit)/1000);

%% ================= COMBINED PLOT: q vs RH (ALL TEMPS) =================
figure; hold on;

for i = 1:nT
    P   = P_all{i};
    q   = q_all{i};
    T_K = TK_all(i);

    P0 = P0_water_Pa(T_K, A_sat, B_sat, C_sat);
    RH = 100 * (P ./ P0);

    scatter(RH, q, 60, 'filled');

    RH_grid = linspace(max(0,min(RH)), min(99.9,max(RH)), 400);
    P_grid  = (RH_grid/100) * P0;
    q_grid  = qPT(P_grid, T_K);

    plot(RH_grid, q_grid, 'LineWidth', 2);
end

xlabel('Relative Humidity (%RH)');
ylabel('Water uptake q (mol/kg)');
title('Water uptake vs RH: experimental points and fitted GAB model (all temperatures)');
legend( ...
    sprintf('Exp %.0f°C', Temps_C(1)), sprintf('Fit %.0f°C', Temps_C(1)), ...
    sprintf('Exp %.0f°C', Temps_C(2)), sprintf('Fit %.0f°C', Temps_C(2)), ...
    sprintf('Exp %.0f°C', Temps_C(3)), sprintf('Fit %.0f°C', Temps_C(3)), ...
    'Location','best');
grid on;

%% ================= DIAGNOSTIC PLOTS + ERROR METRICS (PER TEMPERATURE) =================
fprintf('\n=== Per-temperature fit quality metrics ===\n');
fprintf('Metrics reported: R^2, MAE, RMSE, MedAE\n\n');

for i = 1:nT
    P = P_all{i};
    q = q_all{i};
    T_K = TK_all(i);

    q_pred = qPT(P, T_K);

    % R^2
    SS_res = sum((q - q_pred).^2);
    SS_tot = sum((q - mean(q)).^2);
    R2_i = 1 - SS_res/SS_tot;

    % Extra error metrics
    abs_err = abs(q - q_pred);
    MAE_i   = mean(abs_err);
    RMSE_i  = sqrt(mean((q - q_pred).^2));
    MedAE_i = median(abs_err);

    fprintf('T = %.0f°C:  R^2=%.4f   MAE=%.4g   RMSE=%.4g   MedAE=%.4g   (mol/kg)\n', ...
        Temps_C(i), R2_i, MAE_i, RMSE_i, MedAE_i);

    % q vs P
    figure;
    scatter(P, q, 60, 'filled'); hold on;
    plot(P, q_pred, 'LineWidth', 2);
    xlabel('Pressure P (Pa)'); ylabel('Uptake q (mol/kg)');
    title(sprintf('Global GAB Fit at %.0f°C (R^2=%.4f | MAE=%.3g | RMSE=%.3g)', Temps_C(i), R2_i, MAE_i, RMSE_i));
    grid on;

    % q vs RH
    P0 = P0_water_Pa(T_K, A_sat, B_sat, C_sat);
    RH = 100 * (P ./ P0);

    RH_grid = linspace(max(0,min(RH)), min(99.9,max(RH)), 300);
    P_grid  = (RH_grid/100) * P0;
    q_grid  = qPT(P_grid, T_K);

    figure;
    scatter(RH, q, 60, 'filled'); hold on;
    plot(RH_grid, q_grid, 'LineWidth', 2);
    xlabel('Relative Humidity (%RH)'); ylabel('Uptake q (mol/kg)');
    title(sprintf('Global GAB Fit: q vs RH at %.0f°C', Temps_C(i)));
    grid on;
end

%% ================= POOLED METRICS (ALL TEMPS TOGETHER) =================
[q_allvec, qhat_allvec] = collectAllObsPred(P_all, q_all, TK_all, qPT);

SS_res_all = sum((q_allvec - qhat_allvec).^2);
SS_tot_all = sum((q_allvec - mean(q_allvec)).^2);
R2_all = 1 - SS_res_all / SS_tot_all;

abs_err_all = abs(q_allvec - qhat_allvec);
MAE_all   = mean(abs_err_all);
RMSE_all  = sqrt(mean((q_allvec - qhat_allvec).^2));
MedAE_all = median(abs_err_all);

fprintf('\n=== Pooled metrics (all temperatures combined) ===\n');
fprintf('R^2=%.4f   MAE=%.4g   RMSE=%.4g   MedAE=%.4g   (mol/kg)\n', ...
    R2_all, MAE_all, RMSE_all, MedAE_all);

%% ================= LOCAL FUNCTIONS =================

function r = globalResidualsWeighted(x, P_all, q_all, TK_all, Npts, equalWeightPerTemp, ...
                                    R, A_sat, B_sat, C_sat)
% Concatenate residuals across all temperatures.
% Optional equal weighting per temperature: divide residuals by sqrt(N_i)
    qm  = exp(x(1));
    dH1 = x(2);
    dHm = x(3);

    r = [];
    for i = 1:numel(TK_all)
        P   = P_all{i};
        q   = q_all{i};
        T_K = TK_all(i);

        q_hat = GAB_qPT(P, T_K, qm, dH1, dHm, R, A_sat, B_sat, C_sat);
        ri = (q_hat - q);

        if equalWeightPerTemp && Npts(i) > 0
            ri = ri ./ sqrt(Npts(i));
        end

        r = [r; ri]; %#ok<AGROW>
    end
end

function q = GAB_qPT(P, T_K, qm, dH1, dHm, R, A_sat, B_sat, C_sat)
% TSA-ready uptake function q(P,T) for water vapour
    P0 = P0_water_Pa(T_K, A_sat, B_sat, C_sat);
    aw = P ./ P0;

    C = exp(dH1 ./ (R .* T_K));
    K = exp(dHm ./ (R .* T_K));

    denom1 = (1 - K .* aw);
    denom2 = (1 + (C - 1) .* K .* aw);

    q = qm .* (C .* K .* aw) ./ (denom1 .* denom2);

    q(aw >= 1) = NaN;
    q(aw <  0) = NaN;
end

function P0 = P0_water_Pa(T_K, A_sat, B_sat, C_sat)
% Your correlation (Pa):
% P0 = (10^3)*EXP(A_sat-(B_sat/(T[K]+C_sat-273.15)))
    P0 = 1e3 * exp(A_sat - (B_sat ./ (T_K + C_sat - 273.15)));
end

function dHL = waterLatentHeat_Jmol(T_K)
% Latent heat of vaporization of water (J/mol) vs temperature.
% User-specified linear correlation:
%   ΔHvap(T) = -2.4363*T(°C) + 2502.4   [kJ/kg]
% Convert kJ/kg -> J/mol

T_C = T_K - 273.15;                     % °C
dHv_kJkg = (-2.4363 .* T_C + 2502.4);   % kJ/kg
dHv_Jkg  = 1000 .* dHv_kJkg;            % J/kg

MW = 0.01801528;                        % kg/mol
dHL = dHv_Jkg .* MW;                    % J/mol
end

function [q_allvec, qhat_allvec] = collectAllObsPred(P_all, q_all, TK_all, qPT)
% Stack all temperatures into one vector for pooled metrics
q_allvec = [];
qhat_allvec = [];
for i = 1:numel(TK_all)
    P = P_all{i};
    q = q_all{i};
    T = TK_all(i);

    qhat = qPT(P, T);

    mask = isfinite(q) & isfinite(qhat);
    q_allvec = [q_allvec; q(mask)]; %#ok<AGROW>
    qhat_allvec = [qhat_allvec; qhat(mask)]; %#ok<AGROW>
end
end
