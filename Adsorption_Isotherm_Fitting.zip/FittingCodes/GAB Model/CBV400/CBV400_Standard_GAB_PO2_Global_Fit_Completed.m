% ============================================================
% Global standard-GAB (PO2) regression for water adsorption
%
% Fits water adsorption isotherms simultaneously at 30, 45 and 60 °C:
%
% q = qm*C(T)*K*aw / [(1-K*aw)*(1-K*aw+C(T)*K*aw)]
%
% C(T) = Cref*exp[(DeltaH1-DeltaHm)/R*(1/T-1/Tref)]
%
% Input file: Fitting2.xlsx
% Columns: P30, q30, P45, q45, P60, q60
% Units: P [Pa], q [mol kg^-1]
%
% Requires MATLAB Optimization Toolbox (lsqnonlin).
% ============================================================

clc; clear; close all;


%% Input
filename  = 'Fitting2.xlsx';
sheetName = 1;

Temps_C = [30,45,60];
T_ref   = 318.15;                 % K (45 °C)

aw_fit_max = 0.75;
exclude_first_n_points = [1,1,1];

R = 8.314462618;                  % J mol^-1 K^-1

% Water saturation-pressure correlation
A_sat = 16.3872;
B_sat = 3885.7;
C_sat = 230.16;


%% Initial estimates and bounds
x0 = [ ...
    10.0; ...                     % qm [mol kg^-1]
    0.6; ...                      % K
    30; ...                       % Cref
    7000];                        % DeltaH1-DeltaHm [J mol^-1]

lb = [1e-8; 1e-6; 1e-8; -2e5];
ub = [100; 0.999999; 1e6; 2e5];


%% Load data
raw = readmatrix(filename,'Sheet',sheetName);

Pcols = [1,3,5];
qcols = [2,4,6];

nT = numel(Temps_C);
TK_all = Temps_C(:)+273.15;

P_all        = cell(nT,1);
q_all        = cell(nT,1);
aw_all       = cell(nT,1);
fit_mask_all = cell(nT,1);

for i = 1:nT

    P = raw(:,Pcols(i));
    q = raw(:,qcols(i));

    valid = isfinite(P) & isfinite(q) & P > 0 & q > 0;

    P = P(valid);
    q = q(valid);

    [P,idx] = sort(P);
    q = q(idx);

    P0 = P0_water_Pa( ...
        TK_all(i),A_sat,B_sat,C_sat);

    aw = P./P0;

    keep = isfinite(aw) & aw >= 0 & aw < 1 & q > 0;

    P  = P(keep);
    q  = q(keep);
    aw = aw(keep);

    fitMask = aw <= aw_fit_max;

    nExclude = exclude_first_n_points(i);

    if nExclude > 0
        fitMask(1:min(nExclude,numel(fitMask))) = false;
    end

    if nnz(fitMask) < 4
        error('Insufficient fitting data at %.0f °C.',Temps_C(i));
    end

    P_all{i}        = P;
    q_all{i}        = q;
    aw_all{i}       = aw;
    fit_mask_all{i} = fitMask;

    fprintf('%.0f °C: %d points used in fit\n', ...
        Temps_C(i),nnz(fitMask));
end


%% Global standard-GAB regression
opts = optimoptions('lsqnonlin', ...
    'Display','final', ...
    'FunctionTolerance',1e-12, ...
    'StepTolerance',1e-12, ...
    'OptimalityTolerance',1e-10, ...
    'MaxIterations',10000, ...
    'MaxFunctionEvaluations',200000);

resfun = @(x) residuals_standard_GAB_global( ...
    x,aw_all,q_all,fit_mask_all,TK_all,T_ref,R);

[x_fit,resnorm] = lsqnonlin( ...
    resfun,x0,lb,ub,opts);

qm_fit   = x_fit(1);
K_fit    = x_fit(2);
Cref_fit = x_fit(3);
dHC_fit  = x_fit(4);

C0_T = Cref_fit.*exp( ...
    (dHC_fit./R).*((1./TK_all)-(1./T_ref)));


%% PO2 polynomial coefficients
% aw/q = A0 + A1*aw + A2*aw^2

A0 = nan(nT,1);
A1 = nan(nT,1);
A2 = nan(nT,1);

for i = 1:nT

    [A0(i),A1(i),A2(i)] = ...
        PO2_coefficients_from_parameters( ...
        qm_fit,K_fit,C0_T(i));
end


%% Predictions and fit statistics
q_model_all = cell(nT,1);

Nfit = nan(nT,1);
RMSE = nan(nT,1);
R2   = nan(nT,1);
MAE  = nan(nT,1);
AARD = nan(nT,1);

q_exp_pool   = [];
q_model_pool = [];

for i = 1:nT

    q_model = standard_GAB_q( ...
        aw_all{i},qm_fit,K_fit,C0_T(i));

    q_model_all{i} = q_model;

    valid = fit_mask_all{i} & ...
            isfinite(q_model) & ...
            isfinite(q_all{i});

    q_exp   = q_all{i}(valid);
    q_model = q_model(valid);

    residual = q_model-q_exp;

    Nfit(i) = numel(q_exp);
    RMSE(i) = sqrt(mean(residual.^2));
    MAE(i)  = mean(abs(residual));
    AARD(i) = 100*mean(abs(residual./q_exp));

    SS_res = sum(residual.^2);
    SS_tot = sum((q_exp-mean(q_exp)).^2);

    R2(i) = 1-SS_res/SS_tot;

    q_exp_pool   = [q_exp_pool; q_exp]; %#ok<AGROW>
    q_model_pool = [q_model_pool; q_model]; %#ok<AGROW>
end


%% Pooled statistics
residual_pool = q_model_pool-q_exp_pool;

RMSE_pool = sqrt(mean(residual_pool.^2));
MAE_pool  = mean(abs(residual_pool));
AARD_pool = 100*mean(abs(residual_pool./q_exp_pool));

SS_res = sum(residual_pool.^2);
SS_tot = sum((q_exp_pool-mean(q_exp_pool)).^2);

R2_pool = 1-SS_res/SS_tot;


%% Results
fprintf('\n=== Global standard-GAB (PO2) fit ===\n');
fprintf('Fitting range: aw <= %.3f\n\n',aw_fit_max);

fprintf('qm                  = %.6g mol kg^-1\n',qm_fit);
fprintf('K                   = %.6g\n',K_fit);
fprintf('Cref (%.2f K)       = %.6g\n',T_ref,Cref_fit);
fprintf('DeltaH1 - DeltaHm   = %.6g kJ mol^-1\n',dHC_fit/1000);
fprintf('Residual norm       = %.6g\n',resnorm);

fprintf('\n=== C0(T) and PO2 coefficients ===\n');
fprintf('T (°C)       C0(T)          A0          A1          A2\n');

for i = 1:nT
    fprintf('%5.0f    %12.6g  %11.6g  %11.6g  %11.6g\n', ...
        Temps_C(i),C0_T(i),A0(i),A1(i),A2(i));
end

fprintf('\n=== Fit statistics ===\n');
fprintf('T (°C)     N       R^2       RMSE       MAE       AARD (%%)\n');

for i = 1:nT
    fprintf('%5.0f    %3d    %8.5f   %9.5g  %9.5g   %9.4f\n', ...
        Temps_C(i),Nfit(i),R2(i),RMSE(i),MAE(i),AARD(i));
end

fprintf('\n=== Pooled statistics ===\n');
fprintf('R^2   = %.6f\n',R2_pool);
fprintf('RMSE  = %.6g mol kg^-1\n',RMSE_pool);
fprintf('MAE   = %.6g mol kg^-1\n',MAE_pool);
fprintf('AARD  = %.4f %%\n',AARD_pool);


%% Fitted isotherms
figure('Color','w');
hold on;

for i = 1:nT

    scatter(aw_all{i},q_all{i},45,'filled', ...
        'DisplayName',sprintf('%.0f °C experimental',Temps_C(i)));

    aw_plot = linspace(0,aw_fit_max,500).';

    q_plot = standard_GAB_q( ...
        aw_plot,qm_fit,K_fit,C0_T(i));

    plot(aw_plot,q_plot,'LineWidth',2, ...
        'DisplayName',sprintf('%.0f °C PO2 fit',Temps_C(i)));
end

xlabel('Water activity, a_w');
ylabel('Water uptake, q (mol kg^{-1})');
xlim([0,aw_fit_max]);
legend('Location','best');
grid on;
box on;


%% Residuals
figure('Color','w');
hold on;

for i = 1:nT

    fitMask = fit_mask_all{i};

    residual = ...
        q_model_all{i}(fitMask)-q_all{i}(fitMask);

    scatter(aw_all{i}(fitMask),residual,45,'filled', ...
        'DisplayName',sprintf('%.0f °C',Temps_C(i)));
end

yline(0,'--');
xlabel('Water activity, a_w');
ylabel('Residual, q_{model}-q_{exp} (mol kg^{-1})');
legend('Location','best');
grid on;
box on;


%% Physical-domain check
aw_check = linspace(0,aw_fit_max,5000).';

fprintf('\n=== Physical-domain check ===\n');

for i = 1:nT

    denominator = ...
        (1-K_fit.*aw_check).* ...
        (1-K_fit.*aw_check+C0_T(i).*K_fit.*aw_check);

    q_check = standard_GAB_q( ...
        aw_check,qm_fit,K_fit,C0_T(i));

    dq_daw = diff(q_check)./diff(aw_check);

    valid_domain = ...
        all(isfinite(q_check)) && ...
        all(q_check >= 0) && ...
        all(denominator > 0) && ...
        all(dq_daw >= -1e-8);

    fprintf('%.0f °C: valid and monotonic = %d\n', ...
        Temps_C(i),valid_domain);
end


%% Local functions
function P0 = P0_water_Pa(T_K,A_sat,B_sat,C_sat)

    T_C = T_K-273.15;

    P0 = 1e3.*exp( ...
        A_sat-B_sat./(T_C+C_sat));
end


function r = residuals_standard_GAB_global( ...
    x,aw_all,q_all,fit_mask_all,TK_all,T_ref,R)

    qm   = x(1);
    K    = x(2);
    Cref = x(3);
    dHC  = x(4);

    C0_T = Cref.*exp( ...
        (dHC./R).*((1./TK_all)-(1./T_ref)));

    r = [];

    for i = 1:numel(TK_all)

        q_model = standard_GAB_q( ...
            aw_all{i},qm,K,C0_T(i));

        mask = fit_mask_all{i};

        r = [r; ...
            q_model(mask)-q_all{i}(mask)]; %#ok<AGROW>
    end
end


function q = standard_GAB_q(aw,qm,K,C0)

    denominator = ...
        (1-K.*aw).* ...
        (1-K.*aw+C0.*K.*aw);

    q = qm.*C0.*K.*aw./denominator;
end


function [A0,A1,A2] = ...
    PO2_coefficients_from_parameters(qm,K,C0)

    A0 = 1./(qm.*C0.*K);

    A1 = A0.*(C0.*K-2.*K);

    A2 = A0.*(K.^2-C0.*K.^2);
end