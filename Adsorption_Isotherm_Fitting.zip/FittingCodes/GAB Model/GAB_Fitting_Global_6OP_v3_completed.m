clc; clear; close all;

%% ================= USER SETTINGS =================
filename  = 'Fitting2.xlsx';   % single sheet, 6 columns: P30 q30 P45 q45 P60 q60
sheetName = 1;

Temps_C       = [30, 45, 60];
aw_max_keep   = 0.999;         % filter near aw->1 to avoid singularities
equalWeightPerTemp = true;

% Polynomial extraction grid (from fitted model)
aw_grid_min = 0.0025;
aw_grid_max = 0.99;
n_aw_grid   = 399;

% Plotting grid for overlays (smooth curves)
aw_plot_min = 0.0;
aw_plot_max = 0.99;
n_aw_plot   = 600;

% Save tables (optional)
writeTables = false;

%% ================= CONSTANTS =================
R = 8.314462618; % J/mol/K

% Water saturation pressure correlation constants (as in your code)
A_sat = 16.3872;
B_sat = 3885.7;
C_sat = 230.16;

%% ================= LOAD + CLEAN DATA =================
raw = readmatrix(filename, 'Sheet', sheetName);

Pcols = [1 3 5];
qcols = [2 4 6];
nT    = numel(Temps_C);

TK_all = Temps_C(:) + 273.15;

P_all  = cell(nT,1);
q_all  = cell(nT,1);
aw_all = cell(nT,1);
Npts   = zeros(nT,1);

for i = 1:nT
    P = raw(:, Pcols(i));
    q = raw(:, qcols(i));

    % Remove NaN/Inf and non-physical
    m = isfinite(P) & isfinite(q) & (P > 0) & (q >= 0);
    P = P(m); q = q(m);

    % Sort by pressure
    [P, idx] = sort(P);
    q = q(idx);

    % Compute aw and filter
    P0 = P0_water_Pa(TK_all(i), A_sat, B_sat, C_sat);
    aw = P ./ P0;

    keep = (aw >= 0) & (aw < aw_max_keep);
    P = P(keep);
    q = q(keep);
    aw = aw(keep);

    P_all{i}  = P;
    q_all{i}  = q;
    aw_all{i} = aw;
    Npts(i)   = numel(P);
end

%% ================= FIT: GLOBAL GENERALIZED 6TH-ORDER GAB =================
% Parameters: [log(qm), dH1, dHm, x1, x2, x3, x4]
qmax_all = max(cellfun(@(v) max(v,[],'omitnan'), q_all));
qm0  = 0.6 * qmax_all;

x0 = [log(max(qm0, eps)), 8000, -2000, 0, 0, 0, 0];

lb = [-Inf, -Inf, -Inf, -Inf, -Inf, -Inf, -Inf];
ub = [ Inf,  Inf,  0,    Inf,  Inf,  Inf,  Inf];   % enforce dHm <= 0

opts = optimoptions('lsqnonlin', ...
    'Display','iter', ...
    'FunctionTolerance',1e-12, ...
    'StepTolerance',1e-12, ...
    'OptimalityTolerance',1e-10, ...
    'MaxIterations',10000, ...
    'MaxFunctionEvaluations',80000);

resfun = @(x) residuals_gen6_weighted( ...
    x, P_all, q_all, TK_all, Npts, equalWeightPerTemp, R, A_sat, B_sat, C_sat);

[x_fit, ~, ~, exitflag] = lsqnonlin(resfun, x0, lb, ub, opts);

qm_fit  = exp(x_fit(1));
dH1_fit = x_fit(2);
dHm_fit = x_fit(3);
x1_fit  = x_fit(4);
x2_fit  = x_fit(5);
x3_fit  = x_fit(6);
x4_fit  = x_fit(7);

fprintf('\n=== GLOBAL 3-TEMPERATURE GENERALIZED (6TH-ORDER) GAB FIT ===\n');
fprintf('q_m                         = %.6g mol/kg\n', qm_fit);
fprintf('dH1 = (ΔH1 - ΔHL)            = %.6g J/mol (%.4f kJ/mol)\n', dH1_fit, dH1_fit/1000);
fprintf('dHm = (ΔHm - ΔHL)            = %.6g J/mol (%.4f kJ/mol)\n', dHm_fit, dHm_fit/1000);
fprintf('x1,x2,x3,x4 (denom poly)     = [%.6g, %.6g, %.6g, %.6g]\n', x1_fit, x2_fit, x3_fit, x4_fit);
fprintf('Difference (ΔH1-ΔHm)         = %.6g J/mol (%.4f kJ/mol)\n', (dH1_fit - dHm_fit), (dH1_fit - dHm_fit)/1000);
fprintf('exitflag                     = %d\n', exitflag);

% Model predictor
qPT = @(P, T_K) GAB_gen6_qPT(P, T_K, qm_fit, dH1_fit, dHm_fit, x1_fit, x2_fit, x3_fit, x4_fit, ...
                            R, A_sat, B_sat, C_sat);

%% ================= EXTRACT POLYNOMIAL SURROGATES (FROM FITTED MODEL) =================
aw_grid = linspace(aw_grid_min, min(aw_grid_max, aw_max_keep), n_aw_grid).';
aw_grid = aw_grid(aw_grid > 0);

po3_coeffs = zeros(nT, 4);   % [a b c d] for aw/q = a + b*aw + c*aw^2 + d*aw^3
po6_coeffs = zeros(nT, 7);   % [A B D E F G H] for aw/q up to aw^6

for i = 1:nT
    T_K = TK_all(i);
    P0  = P0_water_Pa(T_K, A_sat, B_sat, C_sat);

    P_grid = aw_grid .* P0;
    q_grid = qPT(P_grid, T_K);

    y = aw_grid ./ q_grid; % aw/q
    m = isfinite(y) & (q_grid > 0);

    x = aw_grid(m);
    y = y(m);

    % PO3: polyfit returns [d c b a]
    p3 = polyfit(x, y, 3);
    po3_coeffs(i,:) = [p3(4) p3(3) p3(2) p3(1)];

    % PO6: linear regression
    X6 = [ones(size(x)) x x.^2 x.^3 x.^4 x.^5 x.^6];
    b6 = X6 \ y; % [A B D E F G H]'
    po6_coeffs(i,:) = b6(:).';
end

Tpoly3 = table(Temps_C(:), po3_coeffs(:,1), po3_coeffs(:,2), po3_coeffs(:,3), po3_coeffs(:,4), ...
    'VariableNames', {'T_C','a','b','c','d'});

Tpoly6 = table(Temps_C(:), po6_coeffs(:,1), po6_coeffs(:,2), po6_coeffs(:,3), po6_coeffs(:,4), ...
                         po6_coeffs(:,5), po6_coeffs(:,6), po6_coeffs(:,7), ...
    'VariableNames', {'T_C','A','B','D','E','F','G','H'});

fprintf('\n=== Polynomial surrogate parameters (from fitted model) ===\n');
fprintf('PO3 form: aw/q = a + b*aw + c*aw^2 + d*aw^3\n'); disp(Tpoly3);
fprintf('PO6 form: aw/q = A + B*aw + D*aw^2 + E*aw^3 + F*aw^4 + G*aw^5 + H*aw^6\n'); disp(Tpoly6);

if writeTables
    writetable(Tpoly3, 'PO3_coeffs_aw_over_q.csv');
    writetable(Tpoly6, 'PO6_coeffs_aw_over_q.csv');
end

%% ================= NEW FIGURE: OVERLAY EXP vs PO3 vs PO6 (and GenGAB6) =================
aw_plot = linspace(aw_plot_min, min(aw_plot_max, aw_max_keep), n_aw_plot).';

figure('Name','Overlay: Experimental vs PO3 vs PO6 (and GenGAB6)','Color','w');
tiledlayout(1, nT, 'TileSpacing','compact', 'Padding','compact');

for i = 1:nT
    nexttile; hold on;

    % Experimental data
    aw_exp = aw_all{i};
    q_exp  = q_all{i};
    scatter(aw_exp, q_exp, 45, 'filled');

    % Build model curves on aw_plot
    T_K = TK_all(i);
    P0  = P0_water_Pa(T_K, A_sat, B_sat, C_sat);
    P_plot = aw_plot .* P0;

    % GenGAB6 curve
    q_gab = qPT(P_plot, T_K);

    % PO3 curve: q = aw / (a + b*aw + c*aw^2 + d*aw^3)
    a = po3_coeffs(i,1); b = po3_coeffs(i,2); c = po3_coeffs(i,3); d = po3_coeffs(i,4);
    denom3 = a + b*aw_plot + c*aw_plot.^2 + d*aw_plot.^3;
    q_po3 = aw_plot ./ denom3;

    % PO6 curve
    A = po6_coeffs(i,1); B = po6_coeffs(i,2); D = po6_coeffs(i,3); E = po6_coeffs(i,4);
    F = po6_coeffs(i,5); G = po6_coeffs(i,6); H = po6_coeffs(i,7);
    denom6 = A + B*aw_plot + D*aw_plot.^2 + E*aw_plot.^3 + F*aw_plot.^4 + G*aw_plot.^5 + H*aw_plot.^6;
    q_po6 = aw_plot ./ denom6;

    % Safety mask to avoid crazy spikes if denom crosses ~0
    epsDen = 1e-10;
    q_po3(abs(denom3) < epsDen) = NaN;
    q_po6(abs(denom6) < epsDen) = NaN;

    % Plot overlays
    plot(aw_plot, q_gab, 'LineWidth', 2);
    plot(aw_plot, q_po3, 'LineWidth', 2);
    plot(aw_plot, q_po6, 'LineWidth', 2);

    xlabel('Water activity, a_w');
    ylabel('Uptake q (mol/kg)');
    title(sprintf('%.0f^{\\circ}C', Temps_C(i)));
    grid on;

    if i == 1
        legend({'Exp','GenGAB6','PO3','PO6'}, 'Location','best');
    end
end

%% ================= LOCAL FUNCTIONS =================
function r = residuals_gen6_weighted(x, P_all, q_all, TK_all, Npts, equalWeightPerTemp, R, A_sat, B_sat, C_sat)
    qm  = exp(x(1));
    dH1 = x(2);
    dHm = x(3);
    x1  = x(4);
    x2  = x(5);
    x3  = x(6);
    x4  = x(7);

    penalty = 1e6;

    r = zeros(sum(Npts),1);
    k = 1;

    for i = 1:numel(TK_all)
        P   = P_all{i};
        q   = q_all{i};
        T_K = TK_all(i);

        qhat = GAB_gen6_qPT(P, T_K, qm, dH1, dHm, x1, x2, x3, x4, R, A_sat, B_sat, C_sat);
        ri = (qhat - q);

        bad = ~isfinite(ri);
        ri(bad) = penalty;

        if equalWeightPerTemp && Npts(i) > 0
            ri = ri ./ sqrt(Npts(i));
        end

        r(k:k+numel(ri)-1) = ri;
        k = k + numel(ri);
    end
end

function q = GAB_gen6_qPT(P, T_K, qm, dH1, dHm, x1, x2, x3, x4, R, A_sat, B_sat, C_sat)
    P0 = P0_water_Pa(T_K, A_sat, B_sat, C_sat);
    aw = P ./ P0;

    C0 = exp(dH1 ./ (R .* T_K));
    K  = exp(dHm ./ (R .* T_K));

    denomC = 1 + x1.*aw + x2.*aw.^2 + x3.*aw.^3 + x4.*aw.^4;
    tiny = 1e-12;
    C = C0 ./ denomC;

    denom1 = (1 - K .* aw);
    denom2 = (1 + (C - 1) .* K .* aw);

    q = qm .* (C .* K .* aw) ./ (denom1 .* denom2);

    bad = (aw >= 1) | (aw < 0) | (denomC <= tiny) | ~isfinite(q);
    q(bad) = NaN;
end

function P0 = P0_water_Pa(T_K, A_sat, B_sat, C_sat)
    P0 = 1e3 * exp(A_sat - (B_sat ./ (T_K + C_sat - 273.15)));
end
