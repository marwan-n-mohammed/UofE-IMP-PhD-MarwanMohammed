% ============================================================
% Dual-Site Langmuir (DSL) fitting and van't Hoff analysis
%
% Fits CO2 adsorption isotherms independently at 25, 35 and 45 °C
% using a fixed total saturation capacity:
%
%   q = q1*b1*P/(1+b1*P) + q2*b2*P/(1+b2*P)
%   q1 + q2 = q_sat_fixed
%
% Input file: Fitting.xlsx
% Columns: P25, q25, P35, q35, P45, q45
% Units: P [Pa], q [mol kg^-1]
%
% Requires MATLAB Optimization Toolbox (lsqnonlin).
% ============================================================

clc; clear; close all;

%% Input
filename = 'Fitting.xlsx';
sheetName = 1;

Temps_C = [25, 35, 45];
q_sat_fixed = 0.780765;     % mol kg^-1

R = 8.314462618;            % J mol^-1 K^-1
eps_q = 1e-12;

%% Load data
raw = readmatrix(filename, 'Sheet', sheetName);

Pcols = [1, 3, 5];
qcols = [2, 4, 6];

nT = numel(Temps_C);
TK_all = Temps_C(:) + 273.15;

P_all = cell(nT,1);
q_all = cell(nT,1);
Npts  = zeros(nT,1);

for i = 1:nT

    P = raw(:,Pcols(i));
    q = raw(:,qcols(i));

    mask = isfinite(P) & isfinite(q) & (P > 0) & (q >= 0);
    P = P(mask);
    q = q(mask);

    [P,idx] = sort(P);
    q = q(idx);

    P_all{i} = P;
    q_all{i} = q;
    Npts(i) = numel(P);
end

fprintf('\n=== Data points ===\n');
for i = 1:nT
    fprintf('T = %.0f °C: N = %d\n', Temps_C(i), Npts(i));
end

if any(Npts == 0)
    warning('One or more temperatures contain no valid data.');
end


%% Independent DSL fits
% f defines the capacity distribution:
% q1 = f*q_sat_fixed; q2 = (1-f)*q_sat_fixed.

opts = optimoptions('lsqnonlin', ...
    'Display','final', ...
    'FunctionTolerance',1e-10, ...
    'StepTolerance',1e-10, ...
    'OptimalityTolerance',1e-8, ...
    'MaxIterations',3000, ...
    'MaxFunctionEvaluations',8000);

f_T  = nan(nT,1);
q1_T = nan(nT,1);
q2_T = nan(nT,1);
b1_T = nan(nT,1);
b2_T = nan(nT,1);

R2_T    = nan(nT,1);
MAE_T   = nan(nT,1);
RMSE_T  = nan(nT,1);
MedAE_T = nan(nT,1);
AARD_T  = nan(nT,1);

fprintf('\n=== Independent DSL fits ===\n');
fprintf('Fixed q1 + q2 = %.6g mol kg^-1\n', q_sat_fixed);

for i = 1:nT

    P = P_all{i};
    q = q_all{i};

    if numel(P) < 4
        warning('T = %.0f °C has insufficient data for fitting.', Temps_C(i));
        continue;
    end

    % Initial parameter estimates
    Pmin = min(P);
    Pmax = max(P);

    b1_0 = 10/max(Pmin,eps);
    b2_0 = 0.1/max(Pmax,eps);

    f0 = min(max(max(q)/max(q_sat_fixed,eps),0.6),0.99);

    x0 = [logit_safe(f0), ...
          log(max(b1_0,eps)), ...
          log(max(b2_0,eps))];

    resfun = @(x) residuals_fixedSatDSL(x,P,q,q_sat_fixed);

    try

        x_fit = lsqnonlin(resfun,x0,[],[],opts);

        f  = sigmoid(x_fit(1));
        b1 = exp(x_fit(2));
        b2 = exp(x_fit(3));

        % Site 1 is defined as the higher-affinity site
        if b2 > b1
            [b1,b2] = deal(b2,b1);
            f = 1-f;
        end

        q1 = f*q_sat_fixed;
        q2 = (1-f)*q_sat_fixed;

        f_T(i)  = f;
        q1_T(i) = q1;
        q2_T(i) = q2;
        b1_T(i) = b1;
        b2_T(i) = b2;

        q_hat = DSL_qP(P,q1,q2,b1,b2);

        err = q-q_hat;
        abs_err = abs(err);

        SS_res = sum(err.^2);
        SS_tot = sum((q-mean(q)).^2);

        R2_T(i)    = 1-SS_res/SS_tot;
        MAE_T(i)   = mean(abs_err);
        RMSE_T(i)  = sqrt(mean(err.^2));
        MedAE_T(i) = median(abs_err);
        AARD_T(i)  = 100*mean(abs_err./max(abs(q),eps_q));

        fprintf('\nT = %.0f °C\n',Temps_C(i));
        fprintf('q1 = %.6g, q2 = %.6g mol kg^-1\n',q1,q2);
        fprintf('b1 = %.6g, b2 = %.6g Pa^-1\n',b1,b2);
        fprintf(['R^2 = %.4f   MAE = %.6g   RMSE = %.6g   ' ...
                 'MedAE = %.6g mol kg^-1   AARD = %.4f%%\n'], ...
                 R2_T(i),MAE_T(i),RMSE_T(i),MedAE_T(i),AARD_T(i));

    catch ME
        warning('Fit failed at T = %.0f °C: %s',Temps_C(i),ME.message);
    end
end


%% Pooled fit statistics
q_allvec = [];
qhat_allvec = [];

for i = 1:nT

    if ~isfinite(b1_T(i))
        continue;
    end

    P = P_all{i};
    q = q_all{i};

    q_hat = DSL_qP(P,q1_T(i),q2_T(i),b1_T(i),b2_T(i));

    mask = isfinite(q) & isfinite(q_hat);

    q_allvec    = [q_allvec; q(mask)]; %#ok<AGROW>
    qhat_allvec = [qhat_allvec; q_hat(mask)]; %#ok<AGROW>
end

if ~isempty(q_allvec)

    err_all = q_allvec-qhat_allvec;
    abs_err_all = abs(err_all);

    SS_res_all = sum(err_all.^2);
    SS_tot_all = sum((q_allvec-mean(q_allvec)).^2);

    R2_all    = 1-SS_res_all/SS_tot_all;
    MAE_all   = mean(abs_err_all);
    RMSE_all  = sqrt(mean(err_all.^2));
    MedAE_all = median(abs_err_all);
    AARD_all  = 100*mean(abs_err_all./max(abs(q_allvec),eps_q));

    fprintf('\n=== Pooled fit statistics ===\n');
    fprintf(['R^2 = %.4f   MAE = %.6g   RMSE = %.6g   ' ...
             'MedAE = %.6g mol kg^-1   AARD = %.4f%%\n'], ...
             R2_all,MAE_all,RMSE_all,MedAE_all,AARD_all);
end


%% van't Hoff analysis
valid = isfinite(b1_T) & isfinite(b2_T) & ...
        (b1_T > 0) & (b2_T > 0);

if nnz(valid) >= 2

    invT = 1./TK_all(valid);

    p1 = polyfit(invT,log(b1_T(valid)),1);
    p2 = polyfit(invT,log(b2_T(valid)),1);

    dH1_vH = -p1(1)*R;
    dH2_vH = -p2(1)*R;

    doVantHoff = true;

    fprintf('\n=== van''t Hoff analysis ===\n');
    fprintf('Site 1: DeltaH = %.4f kJ mol^-1\n',dH1_vH/1000);
    fprintf('Site 2: DeltaH = %.4f kJ mol^-1\n',dH2_vH/1000);

else

    doVantHoff = false;
    warning('At least two temperatures are required for van''t Hoff analysis.');

end


%% DSL plots
figure('Color','w'); hold on;

for i = 1:nT

    if ~isfinite(b1_T(i))
        continue;
    end

    P = P_all{i};
    q = q_all{i};

    scatter(P,q,45,'filled', ...
        'DisplayName',sprintf('Exp %.0f °C',Temps_C(i)));

    Pg = logspace(log10(min(P)),log10(max(P)),400).';
    qg = DSL_qP(Pg,q1_T(i),q2_T(i),b1_T(i),b2_T(i));

    plot(Pg,qg,'LineWidth',2, ...
        'DisplayName',sprintf('Fit %.0f °C',Temps_C(i)));
end

set(gca,'XScale','log');
xlabel('CO_2 pressure, P (Pa)');
ylabel('CO_2 uptake, q (mol kg^{-1})');
legend('Location','best');
grid on;


figure('Color','w'); hold on;

for i = 1:nT

    if ~isfinite(b1_T(i))
        continue;
    end

    P = P_all{i};
    q = q_all{i};

    scatter(P,q,45,'filled', ...
        'DisplayName',sprintf('Exp %.0f °C',Temps_C(i)));

    Pg = linspace(min(P),max(P),400).';
    qg = DSL_qP(Pg,q1_T(i),q2_T(i),b1_T(i),b2_T(i));

    plot(Pg,qg,'LineWidth',2, ...
        'DisplayName',sprintf('Fit %.0f °C',Temps_C(i)));
end

xlabel('CO_2 pressure, P (Pa)');
ylabel('CO_2 uptake, q (mol kg^{-1})');
legend('Location','best');
grid on;


%% van't Hoff plots
if doVantHoff

    invT_all = 1./TK_all(valid);
    xline = linspace(min(invT_all)*0.999,max(invT_all)*1.001,200);

    figure('Color','w');
    scatter(invT_all,log(b1_T(valid)),80,'filled');
    hold on;
    plot(xline,polyval(p1,xline),'LineWidth',2);
    xlabel('1/T (K^{-1})');
    ylabel('ln(b_1)');
    grid on;

    figure('Color','w');
    scatter(invT_all,log(b2_T(valid)),80,'filled');
    hold on;
    plot(xline,polyval(p2,xline),'LineWidth',2);
    xlabel('1/T (K^{-1})');
    ylabel('ln(b_2)');
    grid on;

end


%% Local functions
function r = residuals_fixedSatDSL(x,P,q,q_sat_fixed)

    f  = sigmoid(x(1));
    b1 = exp(x(2));
    b2 = exp(x(3));

    q1 = f*q_sat_fixed;
    q2 = (1-f)*q_sat_fixed;

    r = DSL_qP(P,q1,q2,b1,b2)-q;
end


function y = sigmoid(x)

    if x >= 0
        y = 1/(1+exp(-x));
    else
        ex = exp(x);
        y = ex/(1+ex);
    end
end


function x = logit_safe(p)

    p = min(max(p,1e-6),1-1e-6);
    x = log(p/(1-p));
end


function q = DSL_qP(P,q1,q2,b1,b2)

    q = q1.*(b1.*P)./(1+b1.*P) + ...
        q2.*(b2.*P)./(1+b2.*P);

    q(P <= 0) = NaN;
end