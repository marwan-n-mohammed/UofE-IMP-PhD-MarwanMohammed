clc; clear; close all;

%% ================= USER SETTINGS =================
filename  = 'Fitting.xlsx';   % single sheet, 6 columns: P25 q25 P35 q35 P45 q45
sheetName = 1;                % 1 or 'Sheet1'

Temps_C = [25, 35, 45];       % fixed by your file format (column pairs)

% ===== HARD-SCRIPTED TOTAL SATURATION CAPACITY (FIXED) =====
q_sat_fixed = 0.780765;         % mol/kg  <<< SET THIS VALUE

%% ================= AARD SETTINGS (UPGRADED) =================
computeAARD = true;           % <<< ON by default
eps_q = 1e-12;                % guard for q_exp ~ 0 (mol/kg)

%% ================= CONSTANTS =================
R = 8.314462618;              % J/mol/K

%% ================= LOAD + CLEAN DATA =================
raw = readmatrix(filename, 'Sheet', sheetName);

Pcols = [1, 3, 5];
qcols = [2, 4, 6];

nT = numel(Temps_C);
TK_all = Temps_C(:) + 273.15;

P_all = cell(nT,1);
q_all = cell(nT,1);
Npts  = zeros(nT,1);

for i = 1:nT
    P = raw(:, Pcols(i));
    q = raw(:, qcols(i));

    mask = isfinite(P) & isfinite(q) & (P > 0) & (q >= 0);
    P = P(mask); q = q(mask);

    [P, idx] = sort(P);
    q = q(idx);

    P_all{i} = P;
    q_all{i} = q;
    Npts(i)  = numel(P);
end

fprintf('\n=== Data point counts after cleaning ===\n');
for i = 1:nT
    fprintf('T = %.0f°C: N = %d\n', Temps_C(i), Npts(i));
end
if any(Npts == 0)
    warning('One or more temperatures have zero valid points after cleaning. Check Excel columns P25/q25/P35/q35/P45/q45.');
end

%% ================= STAGE 1: INDEPENDENT DSL FITS WITH FIXED q_sat =================
% Model at fixed temperature:
%   q(P) = q1*(b1*P)/(1+b1P) + q2*(b2*P)/(1+b2P)
%
% Constraint enforced:
%   q1 + q2 = q_sat_fixed
%
% Parameterization:
%   f in (0,1): q1 = f*q_sat_fixed, q2 = (1-f)*q_sat_fixed
%   b1>0, b2>0
% Fit variables:
%   x = [logit(f), log(b1), log(b2)]

opts = optimoptions('lsqnonlin', ...
    'Display','final', ...
    'FunctionTolerance',1e-10, ...
    'StepTolerance',1e-10, ...
    'OptimalityTolerance',1e-8, ...
    'MaxIterations',3000, ...
    'MaxFunctionEvaluations',8000);

f_T  = nan(nT,1);
q1_T = nan(nT,1);
q2_T = nan(nT,1);
b1_T = nan(nT,1);
b2_T = nan(nT,1);

% Error metrics per temperature
R2_T    = nan(nT,1);
MAE_T   = nan(nT,1);
RMSE_T  = nan(nT,1);
MedAE_T = nan(nT,1);
AARD_T  = nan(nT,1);          % <<< upgraded

fprintf('\n=== STAGE 1: Independent fixed-q_sat DSL fits (q_sat = %.6g mol/kg) ===\n', q_sat_fixed);
if computeAARD
    fprintf('Per-T metrics reported: R^2, MAE, RMSE, MedAE, AARD(%%)  [eps_q=%.1e]\n', eps_q);
else
    fprintf('Per-T metrics reported: R^2, MAE, RMSE, MedAE\n');
end

for i = 1:nT
    P = P_all{i};
    q = q_all{i};

    fprintf('\n--- START fit at T = %.0f°C (N=%d) ---\n', Temps_C(i), numel(P));
    drawnow;

    if numel(P) < 4
        warning('T=%.0f°C has too few points to fit reliably. Skipping.', Temps_C(i));
        continue;
    end

    % Robust-ish initial guesses for b (avoid "stuck" fits):
    Pmin = min(P);
    Pmax = max(P);
    b1_0 = 10 / max(Pmin, eps);
    b2_0 = 0.1 / max(Pmax, eps);

    % Capacity split guess:
    f0 = min(max(max(q)/max(q_sat_fixed,eps), 0.6), 0.99);

    x0 = [logit_safe(f0), log(max(b1_0,eps)), log(max(b2_0,eps))];
    resfun = @(x) residuals_fixedSatDSL(x, P, q, q_sat_fixed);

    try
        x_fit = lsqnonlin(resfun, x0, [], [], opts);

        f  = sigmoid(x_fit(1));
        b1 = exp(x_fit(2));
        b2 = exp(x_fit(3));

        % Site ordering: site 1 = stronger (b1 >= b2)
        if b2 > b1
            [b1, b2] = deal(b2, b1);
            f = 1 - f; % swap capacity split
        end

        q1 = f * q_sat_fixed;
        q2 = (1 - f) * q_sat_fixed;

        % Store parameters
        f_T(i)  = f;
        q1_T(i) = q1;
        q2_T(i) = q2;
        b1_T(i) = b1;
        b2_T(i) = b2;

        % Predictions
        q_hat = DSL_qP(P, q1, q2, b1, b2);

        % ---- Error metrics ----
        % R^2
        SS_res = sum((q - q_hat).^2);
        SS_tot = sum((q - mean(q)).^2);
        R2_T(i) = 1 - SS_res/SS_tot;

        err = q - q_hat;                % exp - model
        abs_err = abs(err);

        MAE_T(i)   = mean(abs_err);
        RMSE_T(i)  = sqrt(mean(err.^2));
        MedAE_T(i) = median(abs_err);

        if computeAARD
            AARD_T(i) = 100 * mean(abs_err ./ max(abs(q), eps_q));
        end

        fprintf('--- DONE fit at T = %.0f°C ---\n', Temps_C(i));
        fprintf('  q1=%.6g, q2=%.6g (q_sat=%.6g)\n', q1_T(i), q2_T(i), q_sat_fixed);
        fprintf('  b1=%.6g 1/Pa, b2=%.6g 1/Pa\n', b1_T(i), b2_T(i));

        if computeAARD
            fprintf('  R^2=%.4f   MAE=%.6g   RMSE=%.6g   MedAE=%.6g   AARD=%.4f%%  (mol/kg)\n', ...
                R2_T(i), MAE_T(i), RMSE_T(i), MedAE_T(i), AARD_T(i));
        else
            fprintf('  R^2=%.4f   MAE=%.6g   RMSE=%.6g   MedAE=%.6g  (mol/kg)\n', ...
                R2_T(i), MAE_T(i), RMSE_T(i), MedAE_T(i));
        end

    catch ME
        warning('Fit failed at T=%.0f°C: %s', Temps_C(i), ME.message);
        continue;
    end
end

%% ================= POOLED METRICS (ALL TEMPS COMBINED) =================
% Pool all valid points across temperatures and compute the same metrics.
q_allvec = [];
qhat_allvec = [];

for i = 1:nT
    if ~isfinite(b1_T(i)), continue; end

    P = P_all{i};
    q = q_all{i};
    q_hat = DSL_qP(P, q1_T(i), q2_T(i), b1_T(i), b2_T(i));

    mask = isfinite(q) & isfinite(q_hat);
    q_allvec    = [q_allvec; q(mask)]; %#ok<AGROW>
    qhat_allvec = [qhat_allvec; q_hat(mask)]; %#ok<AGROW>
end

if isempty(q_allvec)
    warning('No valid fitted points available to compute pooled metrics.');
else
    SS_res_all = sum((q_allvec - qhat_allvec).^2);
    SS_tot_all = sum((q_allvec - mean(q_allvec)).^2);
    R2_all = 1 - SS_res_all/SS_tot_all;

    err_all = q_allvec - qhat_allvec;      % exp - model
    abs_err_all = abs(err_all);

    MAE_all   = mean(abs_err_all);
    RMSE_all  = sqrt(mean(err_all.^2));
    MedAE_all = median(abs_err_all);

    if computeAARD
        AARD_all = 100 * mean(abs_err_all ./ max(abs(q_allvec), eps_q));
    else
        AARD_all = NaN;
    end

    fprintf('\n=== Pooled metrics (all temperatures combined) ===\n');
    if computeAARD
        fprintf('R^2=%.4f   MAE=%.6g   RMSE=%.6g   MedAE=%.6g   AARD=%.4f%%   (eps_q=%.1e)\n', ...
            R2_all, MAE_all, RMSE_all, MedAE_all, AARD_all, eps_q);
    else
        fprintf('R^2=%.4f   MAE=%.6g   RMSE=%.6g   MedAE=%.6g   (mol/kg)\n', ...
            R2_all, MAE_all, RMSE_all, MedAE_all);
    end
end

%% ================= STAGE 2: VAN''T HOFF ANALYSIS (FROM b1(T), b2(T)) =================
valid = isfinite(b1_T) & isfinite(b2_T) & (b1_T > 0) & (b2_T > 0);

if nnz(valid) < 2
    warning('Not enough valid temperatures to perform van''t Hoff analysis (need >=2).');
    doVantHoff = false;
else
    doVantHoff = true;
    invT = 1 ./ TK_all(valid);

    p1 = polyfit(invT, log(b1_T(valid)), 1);
    p2 = polyfit(invT, log(b2_T(valid)), 1);

    dH1_vH = -p1(1) * R;
    dH2_vH = -p2(1) * R;

    fprintf('\n=== STAGE 2: van''t Hoff (from independent fixed-q_sat DSL fits) ===\n');
    fprintf('Site 1: slope=%.6g => dH1=%.6g J/mol (%.4f kJ/mol)\n', p1(1), dH1_vH, dH1_vH/1000);
    fprintf('Site 2: slope=%.6g => dH2=%.6g J/mol (%.4f kJ/mol)\n', p2(1), dH2_vH, dH2_vH/1000);
end

%% ================= FINAL PLOTS (ONLY FIXED-q_total FIT RESULTS) =================
% The plots below use ONLY the parameters obtained from the fixed-q_sat fits.
% No TSA-ready / van't Hoff reconstructed q(P,T) curves are plotted.

%% Plot 1: Independent fixed-q_sat DSL fits (log P axis)
figure('Name','Fixed-q_total DSL fits (log P)','Color','w'); hold on;

for i = 1:nT
    if ~isfinite(b1_T(i)), continue; end

    P = P_all{i}; q = q_all{i};
    scatter(P, q, 45, 'filled', 'DisplayName', sprintf('Exp %.0f°C', Temps_C(i)));

    Pg = logspace(log10(min(P)), log10(max(P)), 400).';
    qg = DSL_qP(Pg, q1_T(i), q2_T(i), b1_T(i), b2_T(i));
    plot(Pg, qg, 'LineWidth', 2, 'DisplayName', sprintf('Fit %.0f°C', Temps_C(i)));
end

set(gca,'XScale','log');
xlabel('CO_2 pressure P (Pa)');
ylabel('CO_2 uptake q (mol/kg)');
title(sprintf('Independent DSL fits (q_1+q_2 = %.3g mol/kg) — log(P)', q_sat_fixed));
grid on; legend('Location','best');

%% Plot 2: Independent fixed-q_sat DSL fits (linear P axis)
figure('Name','Fixed-q_total DSL fits (linear P)','Color','w'); hold on;

for i = 1:nT
    if ~isfinite(b1_T(i)), continue; end

    P = P_all{i}; q = q_all{i};
    scatter(P, q, 45, 'filled', 'DisplayName', sprintf('Exp %.0f°C', Temps_C(i)));

    Pg = linspace(min(P), max(P), 400).';
    qg = DSL_qP(Pg, q1_T(i), q2_T(i), b1_T(i), b2_T(i));
    plot(Pg, qg, 'LineWidth', 2, 'DisplayName', sprintf('Fit %.0f°C', Temps_C(i)));
end

xlabel('CO_2 pressure P (Pa)');
ylabel('CO_2 uptake q (mol/kg)');
title(sprintf('Independent DSL fits (q_1+q_2 = %.3g mol/kg) — linear(P)', q_sat_fixed));
grid on; legend('Location','best');

%% Plot 3: van't Hoff (ln(b1) vs 1/T) from fixed-q_total fits
if doVantHoff
    invT_all = 1 ./ TK_all(valid);
    xline = linspace(min(invT_all)*0.999, max(invT_all)*1.001, 200);

    figure('Name','van''t Hoff site 1 (fixed-q_total fits)','Color','w');
    scatter(invT_all, log(b1_T(valid)), 80, 'filled'); hold on;
    plot(xline, polyval(p1, xline), 'LineWidth', 2);
    xlabel('1/T (1/K)'); ylabel('ln(b_1)');
    title('van ''t Hoff: ln(b_1) vs 1/T (from fixed-q_{total} DSL fits)');
    grid on;

    %% Plot 4: van't Hoff (ln(b2) vs 1/T) from fixed-q_total fits
    figure('Name','van''t Hoff site 2 (fixed-q_total fits)','Color','w');
    scatter(invT_all, log(b2_T(valid)), 80, 'filled'); hold on;
    plot(xline, polyval(p2, xline), 'LineWidth', 2);
    xlabel('1/T (1/K)'); ylabel('ln(b_2)');
    title('van ''t Hoff: ln(b_2) vs 1/T (from fixed-q_{total} DSL fits)');
    grid on;
end

%% ================= LOCAL FUNCTIONS =================
function r = residuals_fixedSatDSL(x, P, q, q_sat_fixed)
% Residuals for fixed-q_total DSL at a single temperature.
% x = [logit(f), log(b1), log(b2)]
% q1 = f*q_sat_fixed, q2 = (1-f)*q_sat_fixed

    f  = sigmoid(x(1));
    b1 = exp(x(2));
    b2 = exp(x(3));

    q1 = f * q_sat_fixed;
    q2 = (1 - f) * q_sat_fixed;

    q_hat = DSL_qP(P, q1, q2, b1, b2);
    r = q_hat - q;
end

function y = sigmoid(x)
% Numerically stable sigmoid
    if x >= 0
        y = 1/(1+exp(-x));
    else
        ex = exp(x);
        y = ex/(1+ex);
    end
end

function x = logit_safe(p)
% Safe logit for p in (0,1)
    p = min(max(p, 1e-6), 1-1e-6);
    x = log(p/(1-p));
end

function q = DSL_qP(P, q1, q2, b1, b2)
% Dual-Site Langmuir q(P) at fixed T (no van't Hoff here).

    q = q1.*(b1.*P)./(1 + b1.*P) + q2.*(b2.*P)./(1 + b2.*P);
    q(P <= 0) = NaN;
end