% ============================================================
% Global carbamate-bicarbonate equilibrium model
%
% Fits CO2 adsorption isotherms simultaneously at 25, 35 and 45 °C.
% Water activity is incorporated into the effective bicarbonate
% equilibrium constant:
%
%   Kb_eff(T) = Kb(T)*a_H2O(T)
%
% Input file: Fitting.xlsx
% Columns: P25, q25, P35, q35, P45, q45
% Units: P [Pa], q [mol kg^-1]
%
% Requires MATLAB Optimization Toolbox (lsqnonlin).
% ============================================================

clc; clear; close all;

%% Input
filename  = 'Fitting.xlsx';
sheetName = 1;

Cs = 1.56153;                  % mol kg^-1

T_C_list = [25, 35, 45];
Tref_C   = 25;

R = 8.314462618;               % J mol^-1 K^-1
T_K_list = T_C_list + 273.15;
Tref_K   = Tref_C + 273.15;

eps_q = 1e-12;


%% Load data
M = readmatrix(filename,'Sheet',sheetName);

if size(M,2) < 6
    error(['Expected six columns: ' ...
           '[P25 q25 P35 q35 P45 q45].']);
end

P_all = cell(3,1);
q_all = cell(3,1);

pairs = {M(:,1),M(:,2); ...
         M(:,3),M(:,4); ...
         M(:,5),M(:,6)};

for i = 1:3

    P = pairs{i,1};
    q = pairs{i,2};

    good = isfinite(P) & isfinite(q) & (P >= 0) & (q >= 0);

    P_all{i} = P(good);
    q_all{i} = q(good);

    P_all{i} = P_all{i}(:);
    q_all{i} = q_all{i}(:);

    if isempty(P_all{i})
        error('No valid data found at %d °C.',T_C_list(i));
    end
end


%% Model
% van't Hoff temperature dependence:
% K(T) = Kref*exp[-dH/R*(1/T - 1/Tref)]

K_vantHoff = @(Kref,dH,T) ...
    Kref.*exp(-(dH./R).*(1./T - 1./Tref_K));

% p = [Kc_ref, dH_c, Kb_eff_ref, dH_b_eff]

model_q = @(p,P,T) carb_bicarb_lumped_isotherm( ...
    P,Cs, ...
    K_vantHoff(p(1),p(2),T), ...
    K_vantHoff(p(3),p(4),T));

res_fun = @(p) global_residuals( ...
    p,P_all,q_all,T_K_list,model_q);


%% Initial estimates and bounds
Pmax_global = max(cellfun(@(x) max(x),P_all));
K_guess = 1/max(Pmax_global,1);

p0 = [K_guess,     -60000, ...
      0.2*K_guess, -70000];

lb = [1e-14, -2.5e5, 1e-14, -2.5e5];
ub = [Inf,     2.5e5, Inf,     2.5e5];


%% Global fit
opts = optimoptions('lsqnonlin', ...
    'Display','final', ...
    'MaxFunctionEvaluations',5e4, ...
    'MaxIterations',2e3, ...
    'FunctionTolerance',1e-12, ...
    'StepTolerance',1e-12, ...
    'OptimalityTolerance',1e-10);

p_fit = lsqnonlin(res_fun,p0,lb,ub,opts);

Kc_ref_fit    = p_fit(1);
dHc_fit       = p_fit(2);
KbEff_ref_fit = p_fit(3);
dHbEff_fit    = p_fit(4);


%% Predictions and fit statistics
q_pred_all = cell(3,1);
res_all    = cell(3,1);

R2_T    = nan(3,1);
MAE_T   = nan(3,1);
RMSE_T  = nan(3,1);
MedAE_T = nan(3,1);
AARD_T  = nan(3,1);

for i = 1:3

    q_pred_all{i} = model_q( ...
        p_fit,P_all{i},T_K_list(i));

    res_all{i} = q_all{i}-q_pred_all{i};

    q_exp = q_all{i};
    q_fit = q_pred_all{i};
    e = q_exp-q_fit;

    SS_res = sum(e.^2);
    SS_tot = sum((q_exp-mean(q_exp)).^2);

    R2_T(i)    = 1-SS_res/SS_tot;
    MAE_T(i)   = mean(abs(e));
    RMSE_T(i)  = sqrt(mean(e.^2));
    MedAE_T(i) = median(abs(e));
    AARD_T(i)  = 100*mean(abs(e)./max(abs(q_exp),eps_q));
end


%% Pooled fit statistics
q_stack    = vertcat(q_all{:});
qhat_stack = vertcat(q_pred_all{:});

e_stack = q_stack-qhat_stack;

SS_res = sum(e_stack.^2);
SS_tot = sum((q_stack-mean(q_stack)).^2);

R2_global    = 1-SS_res/SS_tot;
MAE_global   = mean(abs(e_stack));
RMSE_global  = sqrt(mean(e_stack.^2));
MedAE_global = median(abs(e_stack));
AARD_global  = 100*mean(abs(e_stack)./max(abs(q_stack),eps_q));


%% Equilibrium constants
Kc_T = K_vantHoff( ...
    Kc_ref_fit,dHc_fit,T_K_list);

KbEff_T = K_vantHoff( ...
    KbEff_ref_fit,dHbEff_fit,T_K_list);


%% Results
fprintf('\n=== Global carbamate-bicarbonate fit ===\n');
fprintf('Cs = %.6f mol kg^-1\n',Cs);
fprintf('Reference temperature = %d °C\n\n',Tref_C);

fprintf('Kc_ref       = %.6e Pa^-1\n',Kc_ref_fit);
fprintf('DeltaH_c     = %.2f kJ mol^-1\n',dHc_fit/1000);

fprintf('Kb_eff_ref   = %.6e Pa^-1\n',KbEff_ref_fit);
fprintf('DeltaH_b_eff = %.2f kJ mol^-1\n\n',dHbEff_fit/1000);

fprintf('=== Fit statistics ===\n');
fprintf(['T (°C)     R^2       MAE       RMSE      ' ...
         'MedAE      AARD (%%)\n']);

for i = 1:3
    fprintf('%5d    %8.5f  %9.5g  %9.5g  %9.5g  %9.4f\n', ...
        T_C_list(i),R2_T(i),MAE_T(i),RMSE_T(i), ...
        MedAE_T(i),AARD_T(i));
end

fprintf('\n=== Pooled statistics ===\n');
fprintf('R^2   = %.5f\n',R2_global);
fprintf('MAE   = %.5g mol kg^-1\n',MAE_global);
fprintf('RMSE  = %.5g mol kg^-1\n',RMSE_global);
fprintf('MedAE = %.5g mol kg^-1\n',MedAE_global);
fprintf('AARD  = %.4f %%\n',AARD_global);

fprintf('\n=== Equilibrium constants ===\n');

for i = 1:3
    fprintf(['T = %d °C:  Kc = %.4e Pa^-1,  ' ...
             'Kb_eff = %.4e Pa^-1\n'], ...
             T_C_list(i),Kc_T(i),KbEff_T(i));
end


%% Isotherm plots
for i = 1:3

    figure('Color','w');

    scatter(P_all{i},q_all{i},60,'filled');
    hold on;

    [Ps,idx] = sort(P_all{i});
    plot(Ps,q_pred_all{i}(idx),'-','LineWidth',2);

    xlabel('CO_2 pressure, P (Pa)');
    ylabel('CO_2 uptake, q (mol kg^{-1})');
    title(sprintf('Global fit: %d °C',T_C_list(i)));
    grid on;
end


%% Residual plots
for i = 1:3

    figure('Color','w');

    scatter(P_all{i},res_all{i},60,'filled');
    hold on;
    yline(0,'--');

    xlabel('CO_2 pressure, P (Pa)');
    ylabel('q_{exp} - q_{fit} (mol kg^{-1})');
    title(sprintf('Residuals: %d °C',T_C_list(i)));
    grid on;
end


%% van't Hoff plots
invT = 1./T_K_list;

figure('Color','w');
plot(invT,log(Kc_T),'o-','LineWidth',2);
xlabel('1/T (K^{-1})');
ylabel('ln(K_c)');
grid on;

figure('Color','w');
plot(invT,log(KbEff_T),'o-','LineWidth',2);
xlabel('1/T (K^{-1})');
ylabel('ln(K_{b,eff})');
grid on;


%% Local functions
function r = global_residuals( ...
    p,P_all,q_all,T_K_list,model_q)

    r = [];

    for i = 1:numel(T_K_list)

        qhat = model_q( ...
            p,P_all{i},T_K_list(i));

        r = [r; qhat-q_all{i}]; %#ok<AGROW>
    end
end


function q = carb_bicarb_lumped_isotherm( ...
    P,Cs,K_carb,Kb_eff)

    % Site balance:
    % 2*Kc*P*theta_f^2 + ...
    % (1 + Kb_eff*P)*theta_f - 1 = 0
    %
    % theta_c = Kc*P*theta_f^2
    % theta_b = Kb_eff*P*theta_f
    % q = Cs*(theta_c + theta_b)

    q = zeros(size(P));

    idx = P > 0;
    p = P(idx);

    A = 2.*K_carb.*p;
    B = 1+Kb_eff.*p;
    C = -1;

    disc = max(B.^2-4.*A.*C,0);

    theta_f = zeros(size(p));
    smallA = abs(A) < 1e-30;

    if any(~smallA)
        theta_f(~smallA) = ...
            (-B(~smallA)+sqrt(disc(~smallA))) ./ ...
            (2.*A(~smallA));
    end

    if any(smallA)
        theta_f(smallA) = 1./B(smallA);
    end

    theta_f = min(max(theta_f,0),1);

    theta_c = K_carb.*p.*theta_f.^2;
    theta_b = Kb_eff.*p.*theta_f;

    q(idx) = Cs.*(theta_c+theta_b);
end