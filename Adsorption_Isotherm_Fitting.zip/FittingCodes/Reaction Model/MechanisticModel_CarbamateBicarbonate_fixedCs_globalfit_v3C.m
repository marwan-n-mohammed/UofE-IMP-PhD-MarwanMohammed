clc; clear; close all;

%% GLOBAL FIT: Carbamate + (Bicarbonate * a_H2O lumped) across 25/35/45 °C
% Data format (ONE sheet, 6 columns):
%   Col1 = P25 (Pa), Col2 = q25 (mol/kg),
%   Col3 = P35 (Pa), Col4 = q35 (mol/kg),
%   Col5 = P45 (Pa), Col6 = q45 (mol/kg)
%
% Reference temperature: 25 °C
% Cs is hard-scripted (fixed)
% a_H2O unknown => lump it into Kb_eff(T) = K_bicarb(T) * a_H2O(T)
%
% Fit parameters:
%   p = [Kc_ref, dH_c, KbEff_ref, dH_b]   where K in 1/Pa, dH in J/mol
%
% van’t Hoff:
%   K(T) = K_ref * exp( -(dH/R)*(1/T - 1/Tref) )
%
% Metrics computed (per T + pooled):
%   R2, MAE, RMSE, MedAE, AARD(%)
%
% NOTE on AARD(%):
%   AARD% = 100 * mean( |q_exp - q_fit| / max(|q_exp|, eps_q) )
%   eps_q prevents blow-up when q_exp ~ 0.

%% ---------------- USER SETTINGS (hard-scripted) ----------------
filename  = 'Fitting.xlsx';
sheetName = 1;          % can be 1 or 'Sheet1' etc.

Cs = 1.56153;           % <<< HARD-SCRIPTED: mol amine / kg sorbent (edit)

T_C_list = [25, 35, 45];
Tref_C   = 25;

R = 8.314462618;        % J/mol/K
T_K_list = T_C_list + 273.15;
Tref_K   = Tref_C + 273.15;

%% ---------------- AARD SETTINGS ----------------
computeAARD = true;   % <<< upgrade: ON by default
eps_q = 1e-12;        % guard for q_exp ~ 0 (mol/kg)

%% ---------------- LOAD DATA (6 columns, 3 pairs) ----------------
M = readmatrix(filename, 'Sheet', sheetName);

if size(M,2) < 6
    error('Expected at least 6 columns: [P25 q25 P35 q35 P45 q45]. Found %d columns.', size(M,2));
end

P_all = cell(3,1);
q_all = cell(3,1);

pairs = {M(:,1), M(:,2);  M(:,3), M(:,4);  M(:,5), M(:,6)};

for i = 1:3
    P = pairs{i,1};
    q = pairs{i,2};

    % Keep only valid rows for this temperature (allow NaNs in unused rows)
    good = isfinite(P) & isfinite(q) & (P >= 0) & (q >= 0);
    P = P(good); q = q(good);

    % Ensure column vectors
    P_all{i} = P(:);
    q_all{i} = q(:);
end

% Simple sanity check: make sure we actually have data in each pair
for i = 1:3
    if isempty(P_all{i})
        error('No valid data found for %d°C columns (pair %d). Check NaNs/format.', T_C_list(i), i);
    end
end

%% ---------------- VAN'T HOFF PARAMETERIZATION ----------------
K_vantHoff = @(Kref, dH, T) Kref .* exp( -(dH./R) .* (1./T - 1./Tref_K) );

% Model wrapper: q(P,T)
% p = [Kc_ref, dH_c, KbEff_ref, dH_b]
model_q = @(p, P, T) carb_bicarb_lumped_isotherm( ...
    P, Cs, ...
    K_vantHoff(p(1), p(2), T), ...      % Kc(T)
    K_vantHoff(p(3), p(4), T) ...       % Kb_eff(T) = Kb(T)*a_H2O(T) (lumped)
);

%% ---------------- GLOBAL RESIDUAL FUNCTION ----------------
res_fun = @(p) global_residuals(p, P_all, q_all, T_K_list, model_q);

%% ---------------- INITIAL GUESSES + BOUNDS ----------------
Pmax_global = max(cellfun(@(x) max(x), P_all));
K_guess = 1 / max(Pmax_global, 1);   % 1/Pa

p0 = [ ...
    K_guess,     -60000, ...   % Kc_ref, dH_c (J/mol)
    0.2*K_guess, -70000  ...   % KbEff_ref, dH_b (J/mol)
];

lb = [1e-14, -2.5e5, 1e-14, -2.5e5];
ub = [Inf,    2.5e5, Inf,    2.5e5];

%% ---------------- FIT ----------------
opts = optimoptions('lsqnonlin', ...
    'Display','iter', ...
    'MaxFunctionEvaluations', 5e4, ...
    'MaxIterations', 2e3, ...
    'FunctionTolerance', 1e-12, ...
    'StepTolerance', 1e-12, ...
    'OptimalityTolerance', 1e-10);

p_fit = lsqnonlin(res_fun, p0, lb, ub, opts);

Kc_ref_fit    = p_fit(1);
dHc_fit       = p_fit(2);
KbEff_ref_fit = p_fit(3);
dHb_fit       = p_fit(4);

%% ---------------- POST-PROCESS ----------------
q_pred_all = cell(3,1);
res_all    = cell(3,1);

for i = 1:3
    q_pred_all{i} = model_q(p_fit, P_all{i}, T_K_list(i));
    res_all{i}    = q_all{i} - q_pred_all{i}; % exp - model
end

% Global unweighted R^2 across all points (pooled)
q_stack    = vertcat(q_all{:});
qhat_stack = vertcat(q_pred_all{:});

SS_res = sum((q_stack - qhat_stack).^2);
SS_tot = sum((q_stack - mean(q_stack)).^2);
R2_global = 1 - SS_res/SS_tot;

%% ---------------- ERROR METRICS (per T + pooled) ----------------
% Metrics computed:
%   R2, MAE, RMSE, MedAE, AARD%

metrics_perT = struct('T_C',[],'N',[],'R2',[],'MAE',[],'RMSE',[],'MedAE',[],'AARD',[]);
metrics_perT = repmat(metrics_perT, 3, 1);

for i = 1:3
    q_exp = q_all{i};
    q_fit = q_pred_all{i};
    e     = q_exp - q_fit;  % exp - model

    % R^2 for this temperature
    SS_res_i = sum(e.^2);
    SS_tot_i = sum((q_exp - mean(q_exp)).^2);
    R2_i = 1 - SS_res_i/SS_tot_i;

    % Absolute-error metrics
    MAE_i   = mean(abs(e));
    RMSE_i  = sqrt(mean(e.^2));
    MedAE_i = median(abs(e));

    % AARD% (guard against division by ~0)
    if computeAARD
        AARD_i = 100 * mean(abs(e) ./ max(abs(q_exp), eps_q));
    else
        AARD_i = NaN;
    end

    metrics_perT(i).T_C   = T_C_list(i);
    metrics_perT(i).N     = numel(q_exp);
    metrics_perT(i).R2    = R2_i;
    metrics_perT(i).MAE   = MAE_i;
    metrics_perT(i).RMSE  = RMSE_i;
    metrics_perT(i).MedAE = MedAE_i;
    metrics_perT(i).AARD  = AARD_i;
end

% Pooled metrics across all temperatures
e_stack = q_stack - qhat_stack; % exp - model stacked

MAE_global   = mean(abs(e_stack));
RMSE_global  = sqrt(mean(e_stack.^2));
MedAE_global = median(abs(e_stack));

if computeAARD
    AARD_global = 100 * mean(abs(e_stack) ./ max(abs(q_stack), eps_q));
else
    AARD_global = NaN;
end

%% ---------------- PRINT RESULTS ----------------
fprintf('\n=== GLOBAL FIT: Carbamate + Bicarbonate (lumped Kb_eff = K_bicarb*a_H2O) ===\n');
fprintf('Reference temperature: %d °C\n', Tref_C);
fprintf('Cs (fixed)           : %.6f mol/kg\n', Cs);

fprintf('\nFitted van’t Hoff parameters:\n');
fprintf('Kc_ref (25C)         : %.6e 1/Pa\n', Kc_ref_fit);
fprintf('dH_carb              : %.2f kJ/mol\n', dHc_fit/1000);

fprintf('Kb_eff_ref (25C)     : %.6e 1/Pa  (Kb_eff = K_bicarb*a_H2O)\n', KbEff_ref_fit);
fprintf('dH_bicarb_eff        : %.2f kJ/mol\n', dHb_fit/1000);

fprintf('\n=== Fit error metrics (per temperature) ===\n');
if computeAARD
    fprintf('%6s %8s %10s %12s %12s %12s %10s\n', 'T(°C)','N','R2','MAE','RMSE','MedAE','AARD%');
    for i = 1:3
        fprintf('%6d %8d %10.5f %12.5g %12.5g %12.5g %10.4f\n', ...
            metrics_perT(i).T_C, metrics_perT(i).N, metrics_perT(i).R2, ...
            metrics_perT(i).MAE, metrics_perT(i).RMSE, metrics_perT(i).MedAE, ...
            metrics_perT(i).AARD);
    end
else
    fprintf('%6s %8s %10s %12s %12s %12s\n', 'T(°C)','N','R2','MAE','RMSE','MedAE');
    for i = 1:3
        fprintf('%6d %8d %10.5f %12.5g %12.5g %12.5g\n', ...
            metrics_perT(i).T_C, metrics_perT(i).N, metrics_perT(i).R2, ...
            metrics_perT(i).MAE, metrics_perT(i).RMSE, metrics_perT(i).MedAE);
    end
end

fprintf('\n=== Pooled fit error metrics (all temperatures combined) ===\n');
fprintf('Total N              : %d\n', numel(q_stack));
fprintf('Global R^2 (pooled)  : %.5f\n', R2_global);
fprintf('Global MAE           : %.5g mol/kg\n', MAE_global);
fprintf('Global RMSE          : %.5g mol/kg\n', RMSE_global);
fprintf('Global MedAE         : %.5g mol/kg\n', MedAE_global);
if computeAARD
    fprintf('Global AARD%%         : %.4f %%   (eps_q = %.1e)\n', AARD_global, eps_q);
end

Kc_T = K_vantHoff(Kc_ref_fit, dHc_fit, T_K_list);
Kb_T = K_vantHoff(KbEff_ref_fit, dHb_fit, T_K_list);

fprintf('\nImplied K(T) values:\n');
for i = 1:3
    fprintf('T = %2d °C:  Kc = %.4e 1/Pa,  Kb_eff = %.4e 1/Pa\n', ...
        T_C_list(i), Kc_T(i), Kb_T(i));
end

%% ---------------- PLOTS: ISOTHERMS (per temperature) ----------------
for i = 1:3
    figure;
    scatter(P_all{i}, q_all{i}, 60, 'filled'); hold on;
    [Ps, idx] = sort(P_all{i});
    plot(Ps, q_pred_all{i}(idx), '-', 'LineWidth', 2);
    xlabel('CO_2 Pressure P (Pa)');
    ylabel('Loading q (mol/kg)');
    title(sprintf('Global fit: %d °C', T_C_list(i)));
    grid on;
end

%% ---------------- PLOTS: RESIDUALS vs P (per temperature) ----------------
for i = 1:3
    figure;
    scatter(P_all{i}, res_all{i}, 60, 'filled'); hold on;
    yline(0, '--');
    xlabel('CO_2 Pressure P (Pa)');
    ylabel('Residual q_{exp} - q_{fit} (mol/kg)');
    title(sprintf('Residuals: %d °C', T_C_list(i)));
    grid on;
end

%% ---------------- VAN'T HOFF PLOTS (lnK vs 1/T) ----------------
invT = 1 ./ T_K_list;

figure;
plot(invT, log(Kc_T), 'o-', 'LineWidth', 2);
xlabel('1/T (1/K)');
ylabel('ln(K_c)');
title('van''t Hoff: Carbamate constant');
grid on;

figure;
plot(invT, log(Kb_T), 'o-', 'LineWidth', 2);
xlabel('1/T (1/K)');
ylabel('ln(K_{b,eff})');
title('van''t Hoff: Bicarbonate effective constant (K_bicarb * a_{H2O})');
grid on;

%% ===================== LOCAL FUNCTIONS =====================

function r = global_residuals(p, P_all, q_all, T_K_list, model_q)
% Stack residuals for lsqnonlin: r = q_model - q_exp
    r = [];
    for i = 1:numel(T_K_list)
        P = P_all{i};
        q = q_all{i};
        qhat = model_q(p, P, T_K_list(i));
        r = [r; (qhat - q)];
    end
end

function q = carb_bicarb_lumped_isotherm(P, Cs, K_carb, Kb_eff)
% Carbamate + bicarbonate (unknown a_H2O lumped into Kb_eff)
%
% Quadratic in theta_f:
%   2 K_carb P theta_f^2 + (1 + Kb_eff P) theta_f - 1 = 0
%
% theta_carb   = K_carb P theta_f^2
% theta_bicarb = Kb_eff  P theta_f
% q = Cs (theta_carb + theta_bicarb)

    q = zeros(size(P));
    idx = P > 0;
    p = P(idx);

    A = 2 .* K_carb .* p;
    B = 1 + Kb_eff .* p;
    C = -1;

    disc = B.^2 - 4 .* A .* C;
    disc = max(disc, 0); % numerical safety

    % Robust handling when A ~ 0 (K_carb ~ 0):
    theta_f = zeros(size(p));
    smallA = abs(A) < 1e-30;

    if any(~smallA)
        % Physical root (positive and typically <= 1)
        theta_f(~smallA) = (-B(~smallA) + sqrt(disc(~smallA))) ./ (2 .* A(~smallA));
    end
    if any(smallA)
        theta_f(smallA) = 1 ./ (B(smallA)); % from B*theta_f -1 =0
    end

    % Guard theta_f within physical bounds due to numerical issues
    theta_f = min(max(theta_f, 0), 1);

    theta_carb   = K_carb .* p .* theta_f.^2;
    theta_bicarb = Kb_eff  .* p .* theta_f;

    q(idx) = Cs .* (theta_carb + theta_bicarb);
end